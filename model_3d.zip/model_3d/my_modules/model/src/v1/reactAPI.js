let $MB;

// reactAPI
function $reactAPI(data) {
	return $reactAPI.create(data);
}

//-----------------------
$reactAPI.create = function(data) {
	debugger;
	const $makeDataReactive = $MB.get('makeDataReactive');
	let {
		proxy
	} = $makeDataReactive(data);
	return proxy;
};
//-----------------------
$reactAPI.getRawData = function(data) {
	const $tools = $MB.get('tools');
	return $tools.getRawData(data);
}

export function handle(mb) {
	$MB = mb;
	return $reactAPI;
}
