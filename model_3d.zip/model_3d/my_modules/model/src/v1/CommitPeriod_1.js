let $MB;

class CommitHandle {
  // $count = 0;
  $def;
  $waitingList = new Map();
  //-----------------------
  constructor() {
    const $bb = $MB.get('bb');
    this.$def = $bb.$deferred();
  }
  //-----------------------
  get childsPromise() {
    let waitList = [];
    for (let [view, pr] of this.$waitingList) {
      if (!(pr instanceof Promise)) {
        throw new TypeError('...');
      }

      waitList.push(pr);
    }
    // debugger;
    let pr = Promise.all(waitList);
    return pr;
  }
  //-----------------------
  get promise() {
    // debugger;
    return this.$def.promise;
  }
  //-----------------------
  // 非同步任務
  add(pr, view) {
    // debugger;

    if (!(pr instanceof Promise)) {
      return;
    }
    this.$waitingList.set(view, pr);

    pr.finally(() => {
      // debugger;
      this.$waitingList.delete(view);
      this.end(view);
    });
  }
  //-----------------------
  end(view = null) {
    // debugger;
    if (this.$waitingList.size > 0) {
      return;
    }
    this.$def.resolve();

    if (view != null && typeof(view['emit']) == 'function') {
      view['$emit']({
        type: 'renderEnd'
      });
    }
  }
}
////////////////////////////////////////
class ObCommitHandle extends CommitHandle {
  $observe;
  $executListeners = new Set();
  //-----------------------
  constructor(ob) {
    super();
    this.$observe = ob;
  }
  //-----------------------
  addExecutListener(obj) {
    // debugger;
    this.$executListeners.add(obj);
  }
  //-----------------------
  hasExecut(obj) {
    // debugger;
    return this.$executListeners.has(obj);
  }
  //-----------------------
  setObserve(ob) {
    this.$observe = ob;
  }
  //-----------------------
  // 非同步任務
  add(pr, view) {
    // debugger;

    if (!(pr instanceof Promise)) {
      return;
    }
    this.$waitingList.set(view, pr);
  }
  //-----------------------
  end() {
    debugger;
    this.$waitingList.clear();
    this.$def.resolve();
  }
}
////////////////////////////////////////
export function handle(mb) {
  $MB = mb;
  return {
    CommitHandle,
    ObCommitHandle,
  };
}
