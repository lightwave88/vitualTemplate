let $MB;
// 判斷類型
const $reg_1 = /^r\.length\|/;
const $reg_2 = /^r\.length$/;

let $UID = 0;
//////////////////////////////
class Listener {
	$id;
	$context;

	// 隸屬的 model
	$model;
	//-------------
	$fn_update;
	$fn_remove;
	//-------------

	// this.$fn_update 是否經過第一次執行
	$isInited = false;

	// ob => paths
	$depList = new Map();
	//--------------------------------------
	constructor(model, args = {}) {
		// debugger;

		this.$id = 'listener_' + $UID++;
		this.$model = model;

		let {
			context,
			dataUpdate,
			dataRemove,
		} = args;

		if (context != null) {
			this.$context = context;
			if(typeof(context['$setListener']) == 'function'){
				context.$setListener(this);
			}
		}

		if (typeof(dataUpdate) != 'function') {
			throw new TypeError('...');
		}
		this.$fn_update = dataUpdate;

		if (typeof(dataRemove) == 'function') {
			this.$fn_remove = dataRemove;
		}
	}
	//--------------------------------------
	// callback
	dataChanged(handle) {
		debugger;

		// listener
		// listener
		// listener

		if (!this.$isInited) {
			this.$isInited = true;
		}
		//-------------
		console.log(`listener(${this.$id}) dataUpdate()`)

		const $context = this.$context || null;

		// 重要的地方
		this.clearWatch();
		const observe = this.$model.observe;

		// 避免 listener double 執行
		observe.addExecutListeners(this);

		// 可以知道現在運行的 listener
		// 即使在套嵌的狀況下
		observe.addActiveListener(this);

		debugger;
		let pr = this.$fn_update.call($context, this.$model, handle);
		debugger;

		if (handle != null && pr instanceof Promise) {
			handle.add(pr, $context);
		}
		//--------
		{
			// test
			console.log(`-----listener(${this.$id}).dataChanged()-----`);
			console.dir(this.$depList);
			console.log('----------');
		}
		observe.removeActiveListener(this);
	}
	//--------------------------------------
	// API
	// 當依存的數據不在了
	remove() {
		debugger;

		if (this.$model == null) {
			// 已經被移除
			return;
		}
		//-------------
		if (this.$fn_remove != null) {
			this.$fn_remove.call(this.$context);
		}
		//-------------
		let model = this.$model;
		this.$model = undefined;

		this.clearWatch();
		this.$depList = undefined;
	}
	//--------------------------------------
	isEqual(obj) {
		if (!(obj instanceof Listener)) {
			return false;
		}
		let res = (this.$id == obj.$id);
		return res;
	}
	//--------------------------------------
	addWatch(ob, key) {
		// debugger;

		ob.addListener(this);

		// debugger;
		if (!this.$depList.has(ob)) {
			this.$depList.set(ob, new Set());
		}
		let list = this.$depList.get(ob);
		list.add(key);
	}
	//--------------------------------------
	// 當監聽的 observe delete 會呼叫
	// 避免記憶體泄漏
	removeWatch(ob) {
		// debugger;
		if (this.$depList.has(ob)) {
			let list = this.$depList.get(ob);
			list.clear();
			this.$depList.delete(ob);
		}
	}
	//--------------------------------------
	isMatch(changeList) {
		// debugger;
		let find = false;

		loop: {
			for (let [ob_id, keyList] of changeList) {
				// debugger
				if (this.$depList.has(ob_id)) {
					let keyList_1 = this.$depList.get(ob_id);

					for (let key of keyList) {
						// debugger;
						if (keyList_1.has(key)) {
							find = true;
							break loop;
						}
					}
				}
			} //for
		} // loop

		return find;
	}
	//--------------------------------------
	clearWatch() {
		// debugger;

		for (let [ob, keyList] of this.$depList) {
			// debugger;
			keyList.clear();
			ob.removeListener(this);
			this.$depList.delete(ob);
		}
	}
}
//////////////////////////////

function createListener(model, args = {}) {
	// debugger;

	let listener = new Listener(model, args);
	return listener;
}

export function handle(mb) {
	$MB = mb;
	return createListener;
}
