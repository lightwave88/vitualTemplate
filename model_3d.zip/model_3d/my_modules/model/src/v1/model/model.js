let $MB;

let $UID = 0;

class Model {
	$id;

	// 所屬的 ob
	$observe;
	// $executedList = new Set();
	$listeners = new Set();
	//---------------------------------
	constructor(data = {}) {
		// debugger;
		const $tools = $MB.get('tools');
		const $bb = $MB.get('bb');
		const $makeDataReactive = $MB.get('makeDataReactive');

		this.$id = 'model_' + $UID++;

		let jug_1 = !Array.isArray(data);
		let jug_2 = !$bb.isPlainObject(data)

		if (jug_1 && jug_2) {
			throw new TypeError('...');
		}

		let ob = $tools.getObserve(data);
		if (ob == null) {
			let {
				ob: _ob
			} = $makeDataReactive(data);
			ob = _ob;
			// debugger;
			// 清除初始化生成的 changeList
			// _ob.clearChangeList();
		}
		this.$observe = ob;

		// 傾聽 observe
		ob.addModel(this);
	}
	//---------------------------------
	get data() {
		return this.$observe.data;
	}

	// 取得上層 data 的方式
	get rootData() {
		let rootOb = this.$observe.root;
		return rootOb.data;
	}

	get observe() {
		return this.$observe;
	}

	get fn() {
		return Model;
	}
	//---------------------------------
	// API
	// (funName, context)
	// (fun, context = null)
	// ({})
	// (object)
	effect(options = {}) {
		debugger;
		// const $bb = $MB.get('bb');

		let {
			dataUpdate = null,
			dataRemove = null,
			context = null,
			isWatch = true,
		} = options;

		// dataUpdate
		if (dataUpdate != null && typeof (dataUpdate) == 'string') {
			if (context != null) {
				dataUpdate = context[dataUpdate];
			} else {
				throw new Error('...');
			}
		}
		// dataRemove
		if (dataRemove != null && typeof (dataRemove) == 'string') {
			if (context != null) {
				dataRemove = context[dataRemove];
			} else {
				throw new Error('...');
			}
		}

		let $options = {
			dataUpdate,
			dataRemove,
			context,
			isWatch,
		};

		const createListener = $MB.get('createListener');
		const listener = createListener(this, $options);

		// 登錄 listener
		this.$listeners.add(listener);
		//------------------
		return ((handle = null) => {
			// debugger;
			if (listener.isInited) {
				return;
			}
			listener.dataChanged(handle);
		});
	}
	//---------------------------------
	// data 變動不會被記錄
	silence(isSilence) {
		let ob = this.observe;
		ob.silence(isSilence);
	}
	//---------------------------------
	// 手動加入變動的 path
	// commit() 會用到
	addChange(path) {
		// 未
		// 未
		// 未
	}
	//---------------------------------
	// 跟 effect 類似
	// 但與 path 相依
	watch(path, callback) {
		// 未
		// 未
		// 未
	}
	//---------------------------------
	// 數據必須是 {}|[] 代表一個物件或商品
	// 對同一個譬如商品項目作數據更新
	// 只做指定數據的第一層比較
	//
	updateData(path, newData, compare = true) {
		debugger;
		const $tools = $MB.get('tools');

		let data = $tools.getDataByPath(this.data, path, true);
		debugger;
		$tools.updateData(data, newData, compare);
	}
	//---------------------------------
	// 針對一堆物品作資料更新
	updateList(path, newData, idName) {
		debugger;
		const $tools = $MB.get('tools');

		let oldData = $tools.getDataByPath(this.data, path, true);
		$tools.updateList(oldData, newData, idName);
	}

	static updateList(oldData, newData, idName) {
		debugger;
		const $tools = $MB.get('tools');
		$tools.updateList(oldData, newData, idName);
	}
	//---------------------------------
	// API
	commit(executedList = null) {
		debugger;
		let pr = this.$observe.commit(executedList);
		return pr;
	}
	//---------------------------------
	toJSON() {
		return this.$observe.data;
	}
	//---------------------------------
	isEqaul(model) {
		if (!(model instanceof Model)) {
			return false;
		}
		return (this.$id == model.$id);
	}
	//---------------------------------
	// 取得資料卻不會驚動 proxy
	getRawData(deep = false) {
		const $tools = $MB.get('tools');

		let data = this.$observe.data;

		if (deep == true) {
			let ob = this.$observe;
			ob.silence(true);
			let res = JSON.parse(JSON.stringify(data));
			ob.silence(false);
			return res;
		}
		let res = $tools.getRawData(data);
		return res;
	}
	//---------------------------------
	// callback
	// observe 呼叫
	$$$dataChanged(changeList, handle) {
		// debugger;

		// model
		// model
		// model
		const ob = this.$observe;

		for (let listener of this.$listeners) {
			debugger;
			if (!listener.isMatch(changeList)) {
				debugger;
				continue;
			}
			//--------
			debugger;
			if (ob.hasExecut(listener)) {
				console.log(`<< doubleExecute listener(${listener.$id})>>`);
				continue;
			}
			// 執行 listener 主要任務
			listener.dataChanged(handle);
		} // for

	}
	//---------------------------------
	// callback
	// 當 model 所屬的 observe 被移除
	$$$remove() {
		debugger;
		for (let listener of this.$listeners) {
			listener.remove();
		}
		this.$listeners.clear();
		this.$listeners = undefined;
	}

} // class
//////////////////////////////

function $isDataChanged(model) {
	debugger;
	let ob = model.observe;
	let root = ob.root;

	if (root.$changeList == null || root.$changeList.size == 0) {
		return false;
	}
	return true;
}

export function handle(mb) {
	$MB = mb;
	return Model;
}
