let $MB;

let $UID = 0;

class CommitPeriod {
  $id;
  $def;
  $waitingList = new Map();
  $executListeners = new Set();
  //-----------------------
  constructor(hasExecutList = null) {    
    const $bb = $MB.get('bb');
    this.$def = $bb.$deferred();
    this.$id = $UID++;

    if(hasExecutList != null){
      for (const listener of hasExecutList) {
        this.$executListeners.add(listener);
        hasExecutList.delete(listener);
      }
      hasExecutList = undefined;
    }
  }
  //-----------------------
  get childsPromise() {
    let waitList = [];
    for (let [view, pr] of this.$waitingList) {
      waitList.push(pr);
    }
    // debugger;
    let pr = Promise.all(waitList);
    return pr;
  }
  //-----------------------
  get promise() {
    // debugger;
    return this.$def.promise;
  }
  //-----------------------
  isEqual(cp){
    if(!(cp instanceof CommitPeriod)){
      return false;
    }
    return (this.$id == cp.$id);
  }
  //-----------------------
  // 非同步任務
  add(pr, view) {
    // debugger;
    if (!(pr instanceof Promise)) {
      throw new TypeError('...');
    }
    this.$waitingList.set(view, pr);
  }
  //-----------------------
  end() {
    this.$waitingList.clear();
    this.$executListeners.clear();
    this.$waitingList = undefined;
    this.$executListeners = undefined;

    this.$def.resolve();
  }
  //-----------------------
  addExecutListener(obj) {
    // debugger;
    this.$executListeners.add(obj);
  }
  //-----------------------
  hasExecut(obj) {
    // debugger;
    return this.$executListeners.has(obj);
  }
  //-----------------------
  addExecutView(view){
    let listener = view.$$$modelListener;
    this.$executListeners.add(listener);
  }
  //-----------------------
  removeExecutView(view){
    let listener = view.$$$modelListener;
    this.$executListeners.delete(listener);
  }
}
////////////////////////////////////////
export function handle(mb) {
  $MB = mb;
  return CommitPeriod;
}
