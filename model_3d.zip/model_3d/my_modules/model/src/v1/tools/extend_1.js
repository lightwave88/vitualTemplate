let $MB;
const $extend = {};

{
	// 複製 data 的值
	$extend.copyValue = function (data) {
		let copy = JSON.parse(JSON.stringify(data))
		return copy;
	};
}
//--------------------------------------
/*
$extend.getDataKeys = function (data) {
	const $bb = $MB.get('bb');
	let _class = this.$getClass(data);

	let keys;

	switch (_class) {
		case '[object Object]':
			keys = Object.keys(data);
			break;
		case '[object Array]':
			data.forEach((item, i) => {
				keys.push(i);
			});
			break;
		case '[object Map]':
			keys = Array.from(data.keys());
			break;
		case '[object Set]':
		default:
			break;
	}

	if (!Array.isArray(keys)) {
		throw new TypeError('unSupport data type');
	}
	return keys;
};
*/
//--------------------------------------
$extend.getObserve = function (data) {
	// debugger;

	// 儘量取 rawData 避免不需要的反應
	data = this.getRawData(data);

	if (data == null || typeof (data) != 'object') {
		return null;
	}
	//-------------
	const $config = $MB.get('config');
	let key = $config['ob_attrName'];
	key = this.symbol(key);

	let res = null;

	if (data.hasOwnProperty(key)) {
		res = data[key];
	}
	return res;
};
//--------------------------------------
// 取得 proxy 原始的 data
$extend.getRawData = function (data) {
	// debugger;

	const $config = $MB.get('config');
	let key = $config['rawData_attrName'];
	key = this.symbol(key);

	if (data == null || typeof (data) != 'object') {
		return undefined;
	}

	let res = (data[key] != null) ? data[key] : data;
	return res;
}

//--------------------------------------
$extend.hasObserve = function (data) {
	let res = this.getObserve(data);
	res = (res != null)
	return res;
}
//--------------------------------------
/*
$extend.deleteObserve = function(list) {
	debugger;
	if (!Array.isArray(list)) {
		list = [list];
	}

	while (list.length > 0) {
		let value = list.pop();
		let ob = this.getObserve(value);
		if (ob != null) {
			ob.remove();
		}
	} // while
};
*/
//--------------------------------------
// 在數據後面植入 ob
$extend.dataLinkOb = function (data, ob) {
	const $config = $MB.get('config');
	let ob_attrName = $config['ob_attrName'];
	ob_attrName = this.symbol(ob_attrName);

	Object.defineProperty(data, ob_attrName, {
		value: ob,
		writable: false,
		configurable: false,
		enumerable: false,
	});
};
//--------------------------------------
{
	// 特殊工具
	$extend.symbol = $symbol;
	//------------------
	let $reg_1 = /^Symbol\((.*?)\)$/;
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof (name) == 'symbol') {
			res = name.toString();
			res = res.replace($reg_1, (m, g1) => {
				return g1;
			});
		} else if (typeof (name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
}
//--------------------------------------
// 判斷 key 是否是要讀取 rawData
$extend.isGetRawdata = function (_key) {
	const $config = $MB.get('config');
	let key = $config['rawData_attrName'];
	key = this.symbol(key);
	return (key === _key);
}
//--------------------------------------
// 測試用
$extend.toString = function (value) {
	let isOk = false;
	let res;
	try {
		isOk = true;
		res = value.toString();
	} catch (e) { }
	if (isOk) {
		return res;
	}
	//-------------
	try {
		isOk = true;
		res = value.valueOf();
	} catch (e) { }
	if (isOk) {
		return res;
	}
	//-------------
	res = ('' + value);
	return res;
}
//--------------------------------------
{
	const $reg_1 = /\[(.+?)\]/;
	const $reg_2 = /(['"])(.+?)\1/;
	const $reg_3 = /^\./;
	// 正規化 path
	$extend.regulePath = function (path) {
		// debugger;

		if (path == null) {
			return null;
		} else if (typeof (path) == 'string') {
			path = path.trim();
			if (path.length == 0) {
				return null;
			}
		} else {
			throw new TypeError('...');
		}
		//-------------
		let reg_1 = RegExp($reg_1, 'g');

		path = path.replace(reg_1, (m, g1) => {
			debugger;

			let word = g1;
			word = word.replace($reg_2, (m, g1, g2) => {
				debugger;
				return g2;
			});
			return `.${word}`;
		});
		// debugger;
		path = path.replace($reg_3, '');

		return path;
	};
}
//--------------------------------------
$extend.getClass = function (data) {
	return Object.prototype.toString.call(data);
}
//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $extend;
}
