let $MB;

// API
function $objProxySetting($this) {

	const $makeDataReactive = $MB.get('makeDataReactive');
	const $tools = $MB.get('tools');
	//-----------------------
	return {
		// get
		get(target, key) {
			console.log(`obj.get(${$toString(key)})`);
			if (_isGetRawdata(key)) {
				return target;
			}
			if (typeof (key) == 'symbol') {
				return target[key];
			}
			// debugger;
			//-------------
			// debugger;
			let value = Reflect.get(target, key);
			let ob = _getOb(target);
			//-------------
			_emit('get', ob, target, key);

			return value;
		},
		// set
		set(target, key, value) {
			console.log(`obj.set(${$toString(key)})`);
			// debugger;

			let ob = _getOb(target);
			let prevValue = target[key];
			let prevOb = _getOb(prevValue);

			let isAdd = !(key in target);
			// 以下步驟順序不能變
			//-------------
			// 步驟1
			// 先做數據連接
			// emit 通道才能順暢
			// target[key] = value;
			//-------------
			// 步驟2
			// init 會有特殊狀況
			if (prevOb != null) {
				debugger;
				prevOb.remove();
			}
			//-------------
			// 步驟3
			// debugger;
			let {
				proxy = null,
				value: $value,
			} = $makeDataReactive(value, $this);

			target[key] = (proxy != null) ? proxy : $value;
			//-------------
			_emit('set', ob, target, key);
			if (isAdd) {
				_emit('set.length', ob, target, key);
			}
			return true;
		},
		// has
		has(target, key) {
			console.log(`obj.has(${$toString(key)})`);
			// debugger;

			let ob = _getOb(target);
			let res;
			if (_isGetRawdata(key)) {
				res = true;
			} else {
				res = (key in target);
			}
			//-------------
			_emit('has', ob, target, key);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			console.log('obj.ownKeys()');
			// debugger;
			// 攔截 {}.loop
			let ob = _getOb(target);
			let keys = Reflect.ownKeys(target);

			_emit('ownKeys', ob, target, null);
			return keys
		},
		// delete
		deleteProperty(target, key) {
			console.log(`obj.delete(${$toString(key)})`);
			// debugger;

			let value = Reflect.get(target, key);

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			//-------------
			let ob = _getOb(target);
			let preOb = _getOb(value);
			if (preOb != null) {
				preOb.remove();
			}
			//-------------
			_emit('delete', ob, target, key);

			_emit('delete.length', ob, target, key);
			return res;
		}
	};
}
//----------------------------

// 初級過濾
function _emit(type, ob, target, key) {
	// debugger;

	if (ob.isSilence) {
		return;
	}

	if (key != null) {
		let key_type = typeof (key);

		if (key_type == 'symbol') {
			return;
		}
	}
	//-------------
	let action;
	// 資訊整理
	switch (type) {
		case 'get':
			action = 'read';
			break;
		case 'set':
			action = 'set';
			break;
		case 'set.length':
			action = 'set';
			key = 'length';
			break;
		case 'has':
			action = 'read';
			break;
		case 'ownKeys':
			action = 'read';
			key = 'length';
			break;
		case 'delete':
			action = 'set';
			break;
		case 'delete.length':
			action = 'set';
			key = 'length';
			break;
		default:
			throw new Error('...');
			break;
	}
	//-------------
	ob.emit({
		key,
		action,
		ob,
	});
}
//----------------------------
// for test
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserve(data);
}
//----------------------------
function _hasObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.hasObserve(data);
}

export function handle(mb) {
	$MB = mb;
	return $objProxySetting;
}
