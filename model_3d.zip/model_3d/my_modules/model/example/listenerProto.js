// 超重要重要範例

class ListenerProto {
  model;

  // 重要
  // view 也要遵從次做法
  $isRemove = false;
  //------------------
  get isRemove() {
    return this.$isRemove;
  }
  //------------------
  // 重點
  getMode(data, oldCacheList, factory) {
    debugger;

    const $bb_mode = $bb.model;
    const $tools = $bb_mode.tools;

    let ob = $tools.getObserve(data);
    if (ob == null) {
      return null;
    }
    //-------------
    let listener;
    if (!ob.hasModel()) {
      // 新建的數據
    } else {
      // 舊的數據，從 cache 中找到自己去報到
      debugger;

      for (let i = 0; i < oldCacheList.length; i++) {
        debugger;
        let preListener = oldCacheList[i];

        const isRemove = preListener.isRemove;
        if (isRemove) {
          // 偷懶
          // 照理說 preListener remove 應該要通知 parent 移除
          // 但這裏可以不用，可以等待此時移除
          continue;
        }
        //-------------
        let preModel = preListener.model;

        let preOb = preModel.observe;
        if (preOb.isEqual(ob)) {
          // 找到
          listener = preListener;
          oldCacheList.splice(i, 1);
          break;
        }
      } // for
    }

    if (listener == null) {
      listener = factory(data);
    }
    debugger;
    return listener;
  }
  //------------------
  // 移除沒用的 childs
  removeOldChild(cacheList = []) {
    debugger;
    while (cacheList.length > 0) {
      let listener = cacheList.pop();
      listener.remove();
    }
  }
  //------------------
  dataRemove() {
    debugger;
    console.log('dataRemove')
    this.model = undefined;
    this.$isRemove = true;
  }
  
}
