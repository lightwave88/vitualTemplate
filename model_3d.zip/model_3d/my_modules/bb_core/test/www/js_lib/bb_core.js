// debugger;
import {
	$bb
} from '/src/index.js';

try {
	window['$bb'] = $bb;
} catch (e) {}
