let $MB;

const $a = {
  name: 'a',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//-------------
function loaded(mb) {
  debugger;
  console.log('a...');
  console.dir(mb.modules());
  console.log('----------');
}
//-------------
function handle(mb) {
  debugger;
  $MB = mb;
  $MB.onload(loaded);
  return $a;
}
//-------------
export {
  handle
};
