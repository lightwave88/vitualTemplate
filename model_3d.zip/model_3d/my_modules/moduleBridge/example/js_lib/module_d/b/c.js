debugger;

let $MB;

const $c = {
  name: 'c',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//------------------
function loaded() {
  debugger;
  // 可以取得外部模組
  console.log('c...');
  const outside = this.get('outside');
  $c.outside = outside;
  console.dir(this.modules());
  console.log('----------');
}
//------------------
function handle(mb) {
  debugger;
  $MB = mb;

  this.onload(loaded);
  return $c;
}
//------------------
export {
  handle
};
