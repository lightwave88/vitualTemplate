let $MB;
let $UID = 0;

const $reg_1 = /^\d+$/;

// 負責 link model
class ViewProto {
  $$$id;
  $$$parent;
  //--------
  $$$model;
  // $props = {};
  //--------
  $$$options = {
    keepAlive: false,
  };

  $$$callbacks = {
    dataRemove: undefined,
    dataUpdate: undefined,
    render: undefined,
    init: undefined,
    waiting: undefined,
    done: undefined,
  };

  $$$renderStart_args;
  //--------
  $$$renderDef;
  //--------
  $$$isRemove = false;
  $$$modelListener;
	//-------------
	// root use
	// 處理 rootView.renderEnd
	$$$flag_startRenderCount = 0;

	// commit 用
	$$$flag_commitHandle;
	// 初始化遇到非同步
	$$$flag_hasInitRender = false;
  //-----------------------
  constructor(args, parent) {
    // debugger;
    const $bb = $MB.get('bb');

    this.$$$id = 'bbVeiw_' + ($UID++);

    if (parent != null) {
      this.$$$parent = parent;
    }else{
			const CommitPeriod = $MB.get('CommitPeriod');
			this.$$$flag_commitHandle = new CommitPeriod();
		}
    this.$initDef = $bb.$deferred();
    this.$$$renderDef = $bb.$deferred();
  }
  //-----------------------
  get $model() {
    return this.$$$model;
  }
  //-------------
  get $data() {
    return this.$$$model.data;
  }
  //-------------
  get $root() {
    // debugger;
    let parent = this;
    while (true) {
      if (parent.$$$parent == null) {
        break;
      }
      parent = parent.$$$parent;
    }
    return parent;
  }
  //-------------
  get $id() {
    return this.$$$id;
  }
  //-------------
  get $renderPromise() {
    debugger;
    let jobList = [];

    if (this.$$$renderDef != null) {
      jobList.push(this.$$$renderDef.promise);
    }
    let pr = Promise.all(jobList);
    return pr;
  }
  //-----------------------
  $commit() {
    debugger;
    let pr = this.$$$model.commit();
    return pr;
  }
  //---------------------------------
  // 設置 view.data
  $setData(data) {
    if (this.$$$model != null) {
      throw new Error('...');
    }
    const $bb = $MB.get('bb');
    this.$$$model = $bb.$model.create(data);
  }
  //-----------------------
  $setListener(listener) {
    this.$$$modelListener = listener;
  }
  //-----------------------
  $__dataUpdate(commitHandle = null) {
    debugger;

    const $bb = $MB.get('bb');
    if (this.$$$renderDef == null) {
      this.$$$renderDef = $bb.$deferred();
    }
    //-------------
    let callback;
    // callback
    callback = this.$$$callbacks['dataUpdate'] || null;
    if (callback != null) {
      callback.call(this, this.$$$model);
    }
    //-------------
    // 必要步驟
    this.$__callRoot(commitHandle);

    this.$emit('waiting');
    //-------------
    debugger;
    this.$__render();

    let pr = this.$$$renderDef.promise;
    return pr;
  }
  //---------------------------------
  $isEqual(view) {
    if (!(view instanceof ViewProto)) {
      throw new TypeError('...');
    }
    return this.$id == view.$id;
  }
  //-----------------------
  $emit(eventName, data) {
    // debugger;

    let root = this.$root;
    let args = {
      target: this,
      data,
    };
    root.$__event(eventName, args);
  }
  //-----------------------
  $__event(eventName, args = {}) {
    // debugger;

    let callback;
    switch (eventName) {
      case 'waiting':
        callback = this.$$$callbacks['waiting'] || null;

        if (this.$$$flag_startRenderCount++ > 0) {
          // 不能重複執行
          return;
        }
        if (callback != null) {
          let res = callback.call(this, args);
          if (res != null) {
            this.$$$renderStart_args = res;
          }
        }
        break;
      case 'done':
        this.$$$flag_startRenderCount = 0;
        callback = this.$$$callbacks['done'] || null;
        if (callback != null) {
          callback.call(this, args, this.$$$renderStart_args);
        }
        this.$$$renderStart_args = undefined;
        break;
      default:
        throw new Error(`no this event(${eventName})`);
        break;
    } // switch
    //-------------
    // 往下傳遞
    for (let view of this.$$$waitingList) {
      // debugger;
      view.$__event(eventName, args);
    }
  }
  //-----------------------
  // callback for model
  $__dataRemove() {
    debugger;
    this.$$$isRemove = true;
  }
  //-----------------------
  // 判斷 view 映射的 data 是否已經 remove
  $__isRemove() {
    return (this.$$$isRemove == true);
  }
  //---------------------------------
  // 特殊的地方
  // 處理 root.loading, root.renderEnd
  $__callRoot(handle) {

    if (this.$$$parent != null) {
      // 把過程傳給 root
      let root = this.$root;
      return root.$__callRoot(handle);
    }
    //-------------
    debugger;
    // root view
    // root initRender 不需用到 commitHandle
    if (handle != null) {
      if (handle.isEqual(this.$$$flag_commitHandle)) {
        return;
      }
      this.$$$flag_commitHandle = handle;
      let pr = handle.promise;

      pr.finally(() => {
        debugger;
        this.$$$flag_commitHandle = undefined;
        this.$__allRenderEnd();
      });
    }
    //-------------
    this.$emit('waiting');
  }
}
//////////////////////////////

// 負責 viewCache
class ViewProto_1 extends ViewProto {
  // 之前的 childViews
  $$$childs = {};

  // 記錄現在 load 的 view
  $$$included_childs = {};

  // 要被保存的
  $$$keep_childs = {};
  //--------
  $$$loadName = 'none';

  $$$waitingList = new Set();
  //---------------------------------
  constructor(args, parent) {
    super(args, parent);
  }
  //---------------------------------
  get $isKeepAlive() {
    let keepAlive = this.$$$options.keepAlive;
    return keepAlive;
  }
  //---------------------------------
  $__render() {

    debugger;
    // callback
    // 這程序可能會用到 this.$includeView(...)
    const render = this.$$$callbacks['render'];
    let res;
    if (render != null) {
      debugger;
      res = render.call(this, this.$model);
    }
    debugger;
    //-------------
    // 移除沒用到的 cache
    this.$__removeNoNeedChils();

    debugger;
    // 轉移 cache
    for (let name in this.$$$included_childs) {
      this.$$$childs[name] = this.$$$included_childs[name];
      delete(this.$$$included_childs[name]);
    }
    return res;
  }
  //---------------------------------
  // 模板內使用的命令
  // 重要重要
  // args = (key)
  $includeView(groupName, viewName, data, editData = null, options = {}) {
    debugger;
    const $bb = $MB.get('bb');

    let {
      keepAlive = false,
    } = options;

    if (typeof(groupName) != 'string' || groupName.length == 0) {
      throw new Error('$includeView() groupName Error');
    }

    if (typeof(viewName) != 'string' || viewName.length == 0) {
      throw new Error('$includeView() viewName Error');
    }
    //-------------
    if (!Array.isArray(data) && !$bb.$isPlainObject(data)) {
      // 只能容許 [...],{...}
      throw new TypeError('...');
    }
    const $ob = $bb.$model.tools.getObserve(data);
    if ($ob == null) {
      throw new Error('...');
    }
    //-------------
    let isDataChanged = false;

    if (editData != null) {
      $ob.checkPoint();

      // 可能會激起第二次 commit()
      this.$__editData($ob, editData);

      isDataChanged = $ob.isDataChanged();
    }
    //-------------
    // 從 cache 找 oldView
    let view = this.$__findOldView($ob, groupName, keepAlive);
    debugger;
    if (view != null) {
      // 有找到 cache
      if (isDataChanged) {
        // 避免 view 之前已經 render 過
        this.$__removeExecut(view);
      }
    } else {
      // 新創
      view = this.$__createView(data, viewName, keepAlive);
      if (isDataChanged) {
        // 避免第二次 render
        this.$__addExecut(view);
      }
    }
    //-------------
    // link
    view.$$$parent = this;

    // 記錄在新的 cache
    this.$__recordIncludeView(view, groupName);
    return view;
  }
  //---------------------------------
  // 在 $includeView 呼叫時暫時性的輸出
  $getIndex(outputDom = false) {
    let id = this.$id;
    let dom = document.createElement('b-view');
    dom.setAttribute('id', id);
    if (outputDom) {
      // 若 render 是要用 dom 操作時
      return dom;
    }
    return dom.outerHTML;
  }
  //---------------------------------
  // 重要
  $__findOldView(ob, groupName, keepAlive) {
    debugger;

    let find;

    if (keepAlive) {
      let $cg;

      if (groupName in this.$$$keep_childs) {
        $cg = this.$$$keep_childs[groupName];
      } else {
        return;
      }
      for (let view of $cg) {
        debugger;
        if (view.$__isRemove()) {
          // data 已經被移除了
          continue;
        }
        let preOb = view.$model.observe;
        if (preOb.isEqual(ob)) {
          find = view;
          break;
        }
      }
    } else {
      let $cg;

      if (groupName in this.$$$childs) {
        $cg = this.$$$childs[groupName];
      } else {
        return;
      }

      for (let view of $cg) {
        debugger;
        if (view.$__isRemove()) {
          // data 已經被移除了
          continue;
        }
        let preOb = view.$model.observe;
        if (preOb.isEqual(ob)) {
          find = view;
          $cg.delete(view);
          break;
        }
      }
    }
    //-------------
    return find;
  }
  //---------------------------------
  $__createView(data, viewName, keepAlive) {
    debugger;
    const $api = $MB.get('api');
    const View = $MB.get('View');

    // 必須取得 viewClass 並 instance
    // 取得 setting 是 async
    let pr = $api.get(viewName);

    if (pr == null) {
      throw new Error(`cant't find view(${viewName})`);
    }

    let args = {
      options: {
        keepAlive
      },
      data,
    };

    debugger;
    let view = new View(args, pr, this);

    view.$$$loadName = viewName;
    return view;
  }
  //---------------------------------
  // 記錄被 include 的 view
  $__recordIncludeView(view, group) {
    debugger;
    const ChildGroup = $MB.get('ChildGroup');

    // 等待 view 的非同步任務完成
    this.$$$waitingList.add(view);
    //--------
    if (view.$isKeepAlive) {
      if (!(group in this.$$$keep_childs)) {
        this.$$$keep_childs[group] = new ChildGroup();
      }
      let $cg = this.$$$keep_childs[group];
      $cg.add(view);

    } else {
      if (!(group in this.$$$included_childs)) {
        this.$$$included_childs[group] = new ChildGroup();
      }
      let $cg = this.$$$included_childs[group];
      $cg.add(view);
    }
  }
  //---------------------------------
  // 移除沒被用到的 view
  $__removeNoNeedChils() {
    // debugger;

    let removeList = [];

    for (let name in this.$$$keep_childs) {
      // debugger;
      let $cg = this.$$$keep_childs[name];
      for (let view of $cg) {
        // debugger;
        if (view.$__isRemove()) {
          $cg.delete(view);
          removeList.push(view)
        }
      }
      if ($cg.size == 0) {
        delete(this.$$$keep_childs[name]);
      }
    }
    //-------------
    for (let name in this.$$$childs) {
      // debugger;
      let $cg = this.$$$childs[name];
      let list = $cg.getList(true);

      while (list.length) {
        // debugger;
        let view = list.shift();
        // 沒被用到的 childView
        removeList.push(view);
      }
      delete(this.$$$childs[name]);
    }
    //-------------
    // remove 可以晚點再執行
    // 不影響畫面建構

    if (removeList.length > 0) {
      setTimeout(() => {
        debugger;
        while (removeList.length > 0) {
          let view = removeList.shift();
          view.$rmove();
        }
      });
    }
  }
  //---------------------------------
  $__addExecut(view) {
    if (this.$$$parent != null) {
      let root = this.$root;
      return root.$__addExecut(view);
    }
    //-------------
    debugger;
    this.$$$flag_commitHandle.addExecutView(view);
  }

  $__removeExecut(view) {
    if (this.$$$parent != null) {
      let root = this.$root;
      return root.$__removeExecut(view);
    }
    //-------------
    this.$$$flag_commitHandle.removeExecutView(view);
  }
  //---------------------------------
  $__editData(ob, editData) {
    debugger;

    const $bb = $MB.get('bb');

    let rawData = ob.rawData;
    let data = ob.data;

    if (!$bb.$isPlainObject(editData)) {
      let type = typeof(editData);
      throw new TypeError(`typeError(${type}) must be {...}`);
    }
    const $isArray = Array.isArray(rawData);
    const $silence = ob.silence('r');

    for (const key in editData) {
      debugger;
      let value = editData[key];

      if ($isArray) {
        if (!$reg_1.test(key)) {
          throw new TypeError('...');
        }
        let _key = parseInt(key, 10);
        data[_key] = value;
      } else {
        data[key] = value;
      }
    }
    ob.silence($silence);
  }
}
//////////////////////////////
export function handle(mb) {
  $MB = mb;
}
// 給別人繼承用
export {
  ViewProto_1 as ViewProto,
};
