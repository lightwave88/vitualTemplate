let $MB;

// let $UID = 0;
class CommitPeriod {
  // $id;
  // $waitingList = new Map();
  $executViews = new Set();
  //-----------------------
  constructor() {
    // this.$id = $UID++;
  }
  //-----------------------
  addExecutView(view) {
    this.$executViews.add(view);
  }
  //-----------------------
  removeExecutView(view) {
    throw new Error('...');
    // let listener = view.$$$modelListener;
    // this.$executListeners.delete(listener);
  }
  //-----------------------
  getSet(){
    debugger;
    let data = new Set();    
    for (let view of this.$executViews) {
      let listener = view.$$$modelListener;
      if(listener == null){
        throw new Error('...');
      }
      data.add(listener);      
    }
    this.$executViews.clear();
    this.$executViews = undefined;
    return data;
  }
}
////////////////////////////////////////
export function handle(mb) {
  $MB = mb;
  return CommitPeriod;
}
