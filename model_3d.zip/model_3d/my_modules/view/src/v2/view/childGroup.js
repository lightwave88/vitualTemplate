let $MB;

class ChildGroup {
	$viewName;
	$list = new Map();
	//------------------
	constructor() { }
	//------------------
	get size() {
		return this.$list.size;
	}
	//------------------
	add(view) {
		// debugger;
		let id = view.$id;
		if (this.$list.has(id)) {
			return;
		}
		//--------
		// 確保 views 都同屬同個 loadName
		if (this.$viewName == null) {
			this.$viewName = view.$$$loadName;
		} else {
			if (view.$$$loadName != this.$viewName) {
				// 確保 views 都同屬同個 loadName
				throw new Error('...');
			}
		}
		this.$list.set(id, view);
	}
	//------------------
	has(view) {
		// debugger;
		let id = view.$id;
		return this.$list.has(id);
	}
	//------------------
	delete(view) {
		// debugger;
		let id = view.$id;
		this.$list.delete(id);
		if (this.$list.size == 0) {
			this.clear();
		}
	}
	//------------------
	getMap(clear = false) {
		// debugger;
		let map = new Map(this.$list);
		if (clear) {
			this.clear();
		}
		return map;
	}
	//------------------
	getList(clear = false) {
		// debugger;
		let list = Array.from(this.$list.values());
		if (clear) {
			this.clear();
		}
		return list;
	}
	//------------------
	*[Symbol.iterator]() {
		// debugger;
		let keys = Array.from(this.$list.keys());
		while (keys.length > 0) {
			// debugger;
			let key = keys.shift();
			yield this.$list.get(key);
		}
	}
	//------------------
	clear() {
		// debugger;
		this.$list.clear();
		this.$viewName = undefined;
	}
}
//////////////////////////////
export function handle(mb) {
	$MB = mb;
	return ChildGroup;
}
