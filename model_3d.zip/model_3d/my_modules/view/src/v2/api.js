let $MB;

// const $viewClassList = {};

const $api = {
  // options = {dataUpdate, dataRemove, render}
  create(args, pr, ...prList) {
    debugger;
    const View = $MB.get('View');
    let view = new View(args, pr, null, prList);
    return view;
  },
  //------------------
  // return viewClass
  // options = {dataUpdate, dataRemove, render}
  extend(options = {}) {
    // debugger;
    const View = $MB.get('View');

    return (class extends View {
      constructor(data = {}, options_1 = {}) {
        let args = Object.assign({}, options, options_1);
        super(data, args);
      }
    });
  },
  //------------------
	// 事先登錄 view
	add(name, options = {}) {
		const ViewBracket = $MB.get('ViewBracket');
		ViewBracket.add(name, options);
	},
	//------------------
	// 取得事先登錄 view
  get(name) {
    debugger;
    const ViewBracket = $MB.get('ViewBracket');
    let res = ViewBracket.get(name);

    if (res == null) {
      throw new Error(`no this view(${name} settings)`);
    }
    return res;
	},
  //------------------
  getClass() {
    const View = $MB.get('View');
    return View;
  }

};

export function handle(mb) {
  $MB = mb;
  return $api;
}
