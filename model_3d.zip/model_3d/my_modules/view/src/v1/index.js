import MB from './mb.js';
const $mb = new MB();
//------------------
import {
	handle as h_api
} from './api.js';
$mb.importHandle('api', h_api);
//------------------
import m_view from './view/index.js';
$mb.importModule('View', m_view);
//------------------
import {
	handle as h_viewBracket
} from './viewBracket.js';
$mb.importHandle('ViewBracket', h_viewBracket);

//------------------
export function handle(bb) {
	$mb.import('bb', bb);
	const api = $mb.get('api');
	bb['view'] = api;
}
