let $MB;

const $viewClassList = {};

class ViewBracket {
	$settings = {};
	//-----------------------
	constructor(settings = {}) {
		Object.assign(this.$settings, settings);
	}
	//-----------------------
	getSetting() {
		// 模擬非同步
		let pr = Promise.resolve(this.$settings);
		return pr;
	}
	//-----------------------
	// API
	static add(name, options) {
		$viewClassList[name] = new ViewBracket(options);
	}
	//-----------------------
	// API
	static get(name) {
		let pr = null;

		if (name in $viewClassList) {
			let bracket = $viewClassList[name];
			pr = bracket.getSetting();
		}
		return pr;
	}
}
//////////////////////////////
export function handle(mb) {
	$MB = mb;
	return ViewBracket;
};
