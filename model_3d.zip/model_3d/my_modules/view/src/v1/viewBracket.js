let $MB;

const $viewClassList = {};

class ViewBracket {
	$$$promise;
	$$$settings = {};

	// 測試用模擬 async
	$$$delayTime = 1000;
	//-----------------------
	constructor(settings = {}) {
		Object.assign(this.$$$settings, settings);
		this.$$$promise = new Promise((res, rej) => {
			setTimeout(() => {
				res();
			}, this.$$$delayTime);
		});
	}
	//-----------------------
	get promise() {
		return this.$$$promise;
	}
	//-----------------------
	getSetting() {
		// 模擬非同步
		let pr = this.$$$promise.then(() => {
			return this.$$$settings;
		});
		return pr;
	}
	//-----------------------
	// API
	static add(name, options) {
		$viewClassList[name] = new ViewBracket(options);
	}
	//-----------------------
	// API
	static get(name) {
		let pr = null;

		if (name in $viewClassList) {
			let bracket = $viewClassList[name];
			pr = bracket.getSetting();
		}
		return pr;
	}
}
//////////////////////////////
export function handle(mb) {
	$MB = mb;
	return ViewBracket;
};
