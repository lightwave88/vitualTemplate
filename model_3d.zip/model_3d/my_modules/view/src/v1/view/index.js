import MB from '../mb.js';
const $mb = new MB();
//------------------
import {
	handle as h_viewProto
} from './viewProto.js';
h_viewProto($mb);
//------------------
import {
	handle as h_view
} from './view.js';
$mb.importHandle('View', h_view);
//------------------
import {
	handle as h_childView
} from './childGroup.js';
$mb.importHandle('ChildGroup', h_childView);
//------------------
$mb.export(function() {
	const View = this.get('View');
	return View;
});
//------------------
export default $mb;