import {
  ViewProto
} from "./viewProto.js";
let $MB;

const $reg_1 = /^#/;

class View extends ViewProto {

  $$$element_root;
  $$$element_msg;
  $$$element;
  //-------------
  $$$shadowRoot;
  $$$contentList = [];
  //-------------
  // root use
  // 處理 rootView.renderEnd
  $$$flag_startRenderCount = 0;

  // commit 用
  $$$flag_commitHandle;
  // 初始化遇到非同步
  $$$flag_hasInitRender = false;
  //---------------------------------
  // prList: promiseList 要等待的代辦事件
  constructor(args = {}, pr = null, parent = null, prList = null) {
    // debugger;

    super(args, parent);
    //-------------
    if (pr != null && !(pr instanceof Promise)) {
      throw new TypeError('...');
    }
    args = Object.assign({}, args);

    this.$__init(args);
    //-------------
    // 以下進入非同步
    let pr_1;
    if (prList != null && prList.length > 0) {
      pr_1 = Promise.all(prList);
    }

    // 非同步的問題
    let pr_2 = this.$__init_1(pr, args, pr_1);
    pr_2.catch((er) => {
      throw er;
    });
  }
  //---------------------------------
  get $el() {
    return this.$$$element || null;
  }

  get $rootEl() {
    return this.$$$element_root || null;
  }

  get $msgEl() {
    return this.$$$element_msg || null;
  }
  //---------------------------------
  $remove() {
    debugger;

    this.$rootEl.remove();
    this.$$$parent = undefined;
    //--------
    for (let name in this.$$$keep_childs) {
      debugger;
      let list = this.$$$keep_childs[name];
      for (let view of list) {
        view.$remove();
        list.delete(view);
      }
      delete(this.$$$keep_childs[name]);
    }
    //--------
    debugger;
    for (let name in this.$$$childs) {
      debugger;
      let list = this.$$$childs[name];
      for (let view of list) {
        view.$remove();
        list.delete(view);
      }
      delete(this.$$$childs[name]);
    }
    //--------
    this.$el.innerHTML = '';
    this.$msgEl.innerHTML = '';
    this.$rootEl.innerHTML = '';
  }
  //``---------------------------------
  $detache() {
    this.$$$element.remove();
  }
  //---------------------------------
  $out(value){
    return this.$print(value);
  }

  $write(value){
    return this.$print(value);
  }

  // API
  $print(value) {
    let content;
    if (typeof(value) == 'object') {
      if (value == null) {
        if (typeof(value) == 'undefined') {
          content = 'undefined';
        } else {
          content = 'null';
        }
      } else {
        content = JSON.stringify(value);
      }
    } else {
      content = '' + value;
    }
    this.$$$contentList.push(content);
    return content;
  }
  //---------------------------------
  // API
  $attachShadow() {
    this.$$$shadowRoot = document.createDocumentFragment();
    return this.$$$shadowRoot;
  }
  //---------------------------------
  $__render() {
    debugger;

    this.$$$waitingList.clear();

    // renderRes virtualDom 用到
    const renderRes = super.$__render();
    //------------------
    debugger;
    let tempDom;
    if (this.$$$shadowRoot != null) {
      // 用 dom 建構頁面
      // use shadowRoot
      tempDom = this.$$$shadowRoot;
    } else {
      // 用 string 建構頁面
      tempDom = document.createElement('div');
      if (this.$$$contentList.length > 0) {
        let content = this.$$$contentList.join('');
        tempDom.innerHTML = content;
        this.$$$contentList.length = 0;
      }
    }
    //------------------
    let waitingList = Array.from(this.$$$waitingList);

    waitingList = waitingList.map((view) => {
      return view.$renderPromise;
    });
    // debugger;
    // 以下非同步
    // 將跳到其他步驟
    let pr = Promise.all(waitingList);
    debugger;
    pr.then(() => {
      this.$__render_1(tempDom)
    }, (er) => {
      throw er;
    });
  } //---------------------------------
  $__render_1(tempDom) {
    debugger;

    let id = this.$id;

    // 所有被 includeView
    for (let view of this.$$$waitingList) {
      // debugger;
      let view_id = view.$id;
      let childDom = view.$rootEl;

      let selector = `#${view_id}`;
      let dom = tempDom.querySelector(selector);
      dom.replaceWith(childDom);
    }

    //------------------
    debugger;
    // 所有 content 都齊了，放上 dom

    this.$el.innerHTML = '';

    let nodeName = tempDom.nodeName;

    if (nodeName == '#document-fragment') {
      this.$el.appendChild(tempDom);
    } else {
      let childs = Array.from(tempDom.childNodes);
      while (childs.length > 0) {
        let childDom = childs.shift();
        this.$el.appendChild(childDom);
      }
    }
    // debugger;
    if (this.$$$shadowRoot != null) {
      this.$$$shadowRoot = undefined;
    }
    //------------------
    this.$__renderEnd();
  }
  //---------------------------------
  $__renderEnd() {
    // debugger;

    if (this.$$$parent == null) {
      // root
      if (!this.$$$flag_hasInitRender) {
        let pr = this.$$$model.commit();
        pr.finally(() => {
          this.$__allRenderEnd();
        });
      }
    } else {
      if (!this.$$$flag_hasInitRender) {
        this.$$$flag_hasInitRender = true;
      }
      this.$emit('done');
    }
    //--------
    let def = this.$$$renderDef;
    this.$$$renderDef = undefined;
    def.resolve();
    //--------
  }
  //---------------------------------
  $__allRenderEnd() {
    // debugger;
    // root
    // 主要目的
    this.$emit('done');

    if (!this.$$$flag_hasInitRender) {
      this.$$$flag_hasInitRender = true;
    }
  }
  //---------------------------------
  $__init(args) {
    // 非同步之前
    // debugger;
    this.$__checkOptions(args);

    if (this.$$$parent == null) {
      this.$__checkElement(args);
    }

    this.$__checkData(args);

    this.$__checkCallback(args);

    this.$__checkExtend(args);
    //-------------
    // debugger;
    // rootView 執行 callback
    if (this.$$$callbacks['waiting'] != null) {
      let fn = this.$$$callbacks['waiting'];
      this.$$$callbacks['waiting'] = undefined;

      if (this.$$$parent == null) {
        // 只有 rootView 能執行
        // childView 執行沒用
        let res = fn.call(this);
        if (res != null) {
          this.$$$renderStart_args = res;
        }
      }
    }
    //-------------
    if (this.$$$parent == null) {
      // 避免 init 執行 renderStart(...)
      ++this.$$$flag_startRenderCount;
    }
  }
  //---------------------------------
  async $__init_1(pr, args = {}, pr_1) {
    debugger;
    // 非同步之後

    // 要等待的事項
    if (pr_1 != null) {
      await pr_1;
    }
    debugger;
    if (pr != null) {
      let settings = await pr;
      args = Object.assign({}, settings, args);
    }
    //------------
    // debugger;
    this.$__checkOptions(args);

    this.$__checkElement(args);

    this.$__checkData(args);

    this.$__checkCallback(args);

    this.$__checkExtend(args);
    //------------
    pr = this.$__checkInitCallback();
    if (pr != null) {
      await pr;
    }
    //------------
    if (this.$$$model == null) {
      throw new Error('...');
    }
    //------------
    debugger;
    // 監聽 model
    const effect = this.$$$model.effect({
      dataUpdate: ($m, commitHandle) => {
        // debugger;
        let pr = this.$__dataUpdate(commitHandle);
        return pr;
      },
      dataRemove: () => {
        this.$__dataRemove();
      },
      context: this,
    });
    debugger;
    effect();
  }
  //---------------------------------
  $__checkOptions(args) {
    // debugger;
    let options;
    if ('options' in args) {
      options = args['options'];
      delete(args['options']);
    }
    if (options == null) {
      return;
    }
    options = Object.assign({}, options);

    for (let key in this.$$$options) {
      if (this.$$$options != null) {
        // 設定過了
        continue;
      }
      if (key in this.options) {
        this.$$$options[key] = options[key];
      }
    }
  }
  //---------------------------------
  $__checkCallback(args) {
    // debugger;

    // about callback
    for (let key in this.$$$callbacks) {
      if (this.$$$callbacks[key] != null) {
        continue;
      }
      let $key = ('$' + key)
      let value = args[$key];
      if (typeof(value) == 'function') {
        this.$$$callbacks[key] = value;
        delete(args[$key]);
      }
    }
  }
  //---------------------------------
  $__checkData(args) {

    if ('data' in args) {
      let data;
      if (typeof(args['data']) == 'function') {
        data = args['data'].call(this);
      } else {
        data = args['data'];
      }
      delete(args['data']);

      this.$setData(data);
    }
  }
  //---------------------------------
  $__checkExtend(args) {
    // extends
    for (let key in args) {
      let value = args[key];
      delete(args[key]);
      if (this[key] != null) {
        continue;
      }
      this[key] = value;
    }
  }
  //---------------------------------
  $__checkInitCallback() {
    // debugger;
    let pr;
    if (this.$$$callbacks.init != null) {
      let fn = this.$$$callbacks.init;
      delete(this.$$$callbacks.init);

      let res = fn.call(this);
      if (pr instanceof Promise) {
        pr = res;
      }
    }
    return pr;
  }
  //---------------------------------
  $__checkElement(args) {
    // debugger;

    if (this.$$$element_root != null) {
      // 若在非同步之前就已經指定
      return;
    }
    let rootEl;
    if ('el' in args) {
      rootEl = args.el;
      delete(args.el);

      if (typeof(rootEl) == 'string') {
        if ($reg_1.test(rootEl)) {
          rootEl = document.querySelector(rootEl);
        } else {
          rootEl = document.createElement(rootEl);
        }
      }
      this.$$$element_root = rootEl;
    }

    if (this.$$$element_root == null) {
      throw new Error('...');
    }

    rootEl.setAttribute('id', `b-view-${this.$id}`);
    rootEl.className = 'b_view_rootElement';

    //------------
    let msgEl = document.createElement('div');
    let el = document.createElement('div');

    msgEl.className = 'b_view_msgElement';
    el.className = 'b_view_element';

    rootEl.appendChild(msgEl);
    rootEl.appendChild(el);

    this.$$$element_msg = msgEl;
    this.$$$element = el;
  }
  //---------------------------------
  // 特殊的地方
  // 處理 root.loading, root.renderEnd
  $__callRoot(handle) {

    if (this.$$$parent != null) {
      // 把過程傳給 root
      let root = this.$root;
      return root.$__callRoot(handle);
    }
    //-------------
    // root view

    if (this.$$$flag_hasInitRender) {
      // root initRender 不需用到 commitHandle

      if (handle != null && this.$$$flag_commitHandle == null) {
        this.$$$flag_commitHandle = handle;
        let pr = handle.promise;

        pr.finally(() => {
          debugger;
          this.$$$flag_commitHandle = undefined;
          this.$__allRenderEnd();
        });
      }
    }
    //-------------
    this.$emit('waiting');
    //-------------
  }
} // class

export function handle(mb) {
  $MB = mb;
  return View;
}
