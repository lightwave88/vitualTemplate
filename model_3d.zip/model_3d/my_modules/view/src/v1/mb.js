// browser
export * from '../moduleBridge.js';
export {
	default
} from '../moduleBridge.js';
