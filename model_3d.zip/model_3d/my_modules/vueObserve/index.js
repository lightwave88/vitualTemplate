module.exports = {
    observe: require("./observeCommand.js")
};
