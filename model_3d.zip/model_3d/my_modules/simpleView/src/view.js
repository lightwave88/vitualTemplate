let $MB;

let $UID = 0;

class View {
  $id;
  $model;
  //-------------
  $childs = [];
  $caches = [];
  //-------------
  $el;
  $parent;
  $callbacks = {
    '$dataUpdate': null,
    '$dataRemove': null,
    '$remove': null,
  }
  $isRemove = false;

  $contentList = [];
  //-----------------------
  constructor(data, _extends = {}, parent = null) {
    $bb = $MB.get('bb');

    this.$id = `view_${$UID++}`;

    if (parent instanceof View) {
      this.$parent = parent;
    }
    //--------
    _extends = Object.assign({}, _extends);

    // callback
    for (let key in this.$callbacks) {
      if (key in _extends) {
        this.$callbacks[key] = _extends[key];
        delete (_extends[key]);
      }
    } // for
    //--------
    debugger;
    // data
    if ('data' in _extends) {
      let _data = _extends['data'];

      if (typeof (_data) == 'function') {
        data = _data.call(this);
      }
      delete (_extends['data']);
    }
    //--------
    // extends
    for (let key in _extends) {
      this[key] = _extends[key];
    }
    //--------
    if (data == null) {
      throw new Error('no data');
    }
    debugger;
    this.$model = $bb.model.create(data);

    this.$model.effect({
      context: this,
      dataUpdate: () => {
        this.$dataUpdate();
      },
      dataRemove: () => {
        this.$dataRemove();
      }
    })();
  }
  //-----------------------
  get id() {
    return this.$id;
  }

  get model() {
    return this.$model;
  }

  get data() {
    return this.$model.data;
  }

  get isRemove() {
    return this.$isRemove;
  }
  //-----------------------
  $dataUpdate() {
    debugger;

    // reset
    this.$contentList.length = 0;
    //--------
    // callback
    if (this.$callbacks['$dataUpdate'] != null) {
      let fn = this.$callbacks['$dataUpdate'];
      fn.call(this);
    }
    //--------
    // 移除沒被用到的 view
    while (this.$childs.length > 0) {
      debugger;
      let child = this.$childs.shift();
      child.$remove();
    }
    //--------
    this.$childs = this.$caches.slice();
    this.$caches.length = 0;

    this.$out();
  }
  //-----------------------
  $dataRemove() {
    debugger;
    if (this.$callbacks['$dataRemove'] != null) {
      let fn = this.$callbacks['$dataRemove'];
      fn.call(this);
    }
    this.$isRemove = true;
  }
  //-----------------------
  $remove() {
    debugger;

    if (this.$callbacks['$remove'] != null) {
      let fn = this.$callbacks['$remove'];
      fn.call(this);
    }

    if (this.$parent != null) {
      this.$removeChild(this);
      this.$parent = undefined;
    }
    //-------------
    while (this.$childs.length > 0) {
      let child = this.$childs.shift();
      child.$remove();
    }
    //-------------
    this.$destroy();
  }
  //-----------------------
  $removeChild(view) {
    for (let i = 0; i < this.$childs.length; i++) {
      debugger;
      let child = this.$childs[i]
      if (view.$isEqual(child)) {
        this.$childs.splice(i, 1);
        break;
      }
    }
  }
  //-----------------------
  $isEqual(view) {
    if(!(view instanceof View)){
      throw new TypeError('...');
    }
    return (this.id == view.id);
  }
  //-----------------------
  // API
  $includeView(data, viewName) {
    debugger;

    const $API = $MB.get('api');

    let child = this.$searchCaches(data);

    if (child == null) {
      let _extends = $API.get(viewName);
      if (_extends == null) {
        throw new Error('....');
      }
      child = new View(data, _extends, this);
    }
    //-------------
    this.$caches.push(child);
    return child;
  }
  //-----------------------
  $print(text) {
    this.$contentList.push(text);
  }
  //-----------------------
  $out(parent = null) {
    let content = `view(${this.id}) >>\n`;
    content += this.$contentList.join('');
    if (parent == null) {
      console.log(content);
    }
    return content;
  }
  //-----------------------
  // 重點
  // 重點
  // 重點
  $searchCaches(data) {
    debugger;
    const $bb = $MB.get('bb');
    const modelAPI = $bb.model;
    let ob_1 = modelAPI.tools.getObserve(data);

    if (ob_1 == null) {
      throw new Error('....');
    }

    let childView;
    //-------------
    for (let i = 0; i < this.$childs.length; i++) {
      debugger;
      let child = this.$childs[i];
      if (child.isRemove) {
        continue;
      }
      let model = child.model;
      let ob_2 = model.observe;

      if (ob_2.isEqual(ob_1)) {
        childView = child;
        this.$childs.splice(i, 1);
        break;
      }
    }
    debugger;
    //-------------
    return childView;
  }
  //-----------------------
  $destroy() {
    setTimeout(() => {
      this.$contentList.length = 0;

      for (let key in this) {
        if (!this.hasOwnProperty(key)) {
          continue;
        }
      }
      delete (this[key]);
    });
  }
}
//////////////////////////////
export function handle(mb) {
  $MB = mb;
  return View;
}
