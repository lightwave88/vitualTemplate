let $MB;

const $extendsList = new Map();

const $api = {
  create(data, _extends = {}, parent = null) {
    debugger;

    const View = $MB.get('View');
    let view = new View(data, _extends, parent);
    return view;
  },
  //-----------------------
  get(name) {
    let $extend;
    if ($extendsList.has(name)) {
      $extend = $extendsList.get(name);
    }
    return $extend;
  },
  //-----------------------
  add(name, _extends) {
    const $bb = $MB.get('bb');
    if (!$bb.$isPlainObject(_extends)) {
      throw new TypeError('...');
    }
    $extendsList.set(name, _extends);
  },
}

export function handle(mb) {
  $MB = mb;
  return $api;
}
