let data_1 = {
  name: 'a',
  childs: [{
      name: 'b',
      age: 15,
    },
    {
      name: 'c',
      age: 25,
    }
  ]
}


let data_2 = {
   name: 'a',
  childs: [{
      name: 'b',
      age: 15,
    },
  ]
}

module.exports = {
  old: data_1,
  new : data_2
};


