class Container{
  $data = new Map();
  //-----------------------
  constructor() {
    
  }
  //-----------------------
  set(key, value) {
    this.$data.set(key, value);
  }
  //-----------------------
  *[Symbol.iterator]() {
		let keys = Array.from(this.$data.keys());
		while (keys.length > 0) {
			let key = keys.shift();
			yield this.$data.get(key);
		}
	}
}

module.exports = Container;