let data_1 = {
  a: 'a...',
}


let data_2 = {
   b: 'b...'
}

module.exports = {
  old: data_1,
  new : data_2
};


