let data_1 = {
  name: 'a',
  age: 10,
  child: {
    name: 'b',
    age: 15,
    child: {
      name: 'c',
      age: 25,
    }
  }
}


let data_2 = {
  name: 'a',
  age: 10,
  child: {
    name: 'b',
    age: 15,
    child: {
      name: 'c',
      age: 30,
    }
  }
}

module.exports = {
  old: data_1,
  new: data_2
};


