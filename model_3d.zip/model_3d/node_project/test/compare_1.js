class Compare {

  constructor(oldData, newData) {
    this.main(oldData, newData);

    console.log(JSON.stringify(oldData));
    console.log(JSON.stringify(newData));
  }
  //-----------------------
  main(oldData, newData) {
    debugger;

    let $loopList = [];

    $loopList.push({
      old: oldData,
      new: newData,
    });
    //-------------
    this._loopData($loopList);
    //-------------
    this._compare($loopList);
  }
  //-----------------------
  // 採用廣度優先去蒐集配對數據
  _loopData($loopList) {

    let i = 0;
    while (i < $loopList.length) {
      debugger;
      let {
        old: oldValue,
        new: newValue,
        key = null,
      } = $loopList[i++];

      if (key != null) {
        // key == null 是 root
        oldValue = oldValue[key];
        newValue = newValue[key];
      }

      let type_1 = this._getType(oldValue);
      let type_2 = this._getType(newValue);
      //-------------
      if (type_1 == type_2) {
        if (type_1 == '[object Array]') {

          this._compareArrayLength(oldValue, newValue);

          debugger;
          for (let i = 0; i < newValue.length; i++) {
            debugger;
            $loopList.push({
              old: oldValue,
              new: newValue,
              key: i,
            });
          }
          continue;
        } else if (type_1 == '[object Object]') {
          this._compareObjLength(oldValue, newValue)

          debugger;
          for (let key in newValue) {
            debugger;
            $loopList.push({
              old: oldValue,
              new: newValue,
              key,
            });
          }
          continue;
        }
      }
      //-------------
    } // while
  }
  //-----------------------
  _compare(loopList) {
    debugger;

    while (loopList.length > 0) {
      let {
        old: oldData,
        new: newData,
        key,
      } = loopList.pop();

      if (key == null) {
        continue;
      }

      let oldValue = oldData[key];
      let newValue = newData[key];

      if (oldValue !== newValue) {
        oldData[key] = newData[key];
      }
    }
  } // fn

  //-----------------------
  _getType(data) {
    return Object.prototype.toString.call(data);
  }
  //-----------------------
  _compareArrayLength(oldValue, newValue) {
    debugger;

    while (oldValue.length > newValue.length) {
      debugger;
      oldValue.pop();
    }
  }
  //-----------------------
  _compareObjLength(oldValue, newValue) {
    // debugger;

    let oldKeys = Object.keys(oldValue);
    let newKeys = Object.keys(newValue);

    for (let i = 0; i < oldKeys.length; i++) {
      // debugger;
      let key = oldKeys[i];
      if (!newKeys.includes(key)) {
        delete (oldValue[key]);
      }
    } // for
  }
}

module.exports = function (data_1, data_2) {
  debugger;
  new Compare(data_1, data_2);
};