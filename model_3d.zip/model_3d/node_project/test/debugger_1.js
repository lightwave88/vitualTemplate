const Container = require('./container.js');

let c = new Container();
c.set(1, '1...');
c.set(2, '2...');

for (let value of c) {
  debugger;
  console.dir(value);
}

