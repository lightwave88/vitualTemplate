var static = require('node-static_1');
//
// Create a node-static server instance to serve the './public' folder
//
var file = new static.Server();
require('http').createServer(function (request, response) {
  debugger;
  request.addListener('end', function () {
    debugger;
    //
    // Serve files!
    //
    file.serve(request, response);
  }).resume();

  request.resume()

}).listen(8082);