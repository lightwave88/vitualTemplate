(() => {
  //////////////////////////////
  // 
  // 主要測試 
  // 同時
  // child 修改自己的數值
  // 與同時修改 child 的排序
  // 也造成 child.index 的變動
  // 
  // child 變動在 parent 之前
  // 
  //////////////////////////////
  const $options_0 = {
    data() {
      return {
        childs: [{
            name: 'a',
            age: 20,
          },
          {
            name: 'b',
            age: 50,
          }
        ],
      }
    },
    $render() {
      debugger;

      const $data = this.$data;
      let content = '<div>';

      content += `<div>
        <p>name: ${$data.name}</p>
        <p>age: ${$data.age}</p>
      </div>
      <hr>`;

      for (let i = 0; i < $data.childs.length; i++) {
        let d = $data.childs[i];

        // 重點
        // 重點
        let view = this.$includeView('a', 'child', d, {
          index: i
        });
        content += view.$getIndex();
      }
      content += '</div>';
      this.$out(content);
    }
  };
  //////////////////////////////
  const $options_1 = {
    el: 'div',
    $render() {
      debugger;

      const $data = this.$data;
      let content = `<p>index = ${$data.index}</p>`;
      content += `<p>name = ${$data.name}</p>`;
      content += `<p>age = ${$data.age}</p>`;
      this.$out(content);
    }
  };
  //////////////////////////////
  $bb.view.add('parent', $options_0);
  $bb.view.add('child', $options_1);
})();
