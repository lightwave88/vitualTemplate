/*
測試非同步
測試父子的 $waiting, $done
*/

(() => {
	const $options_0 = {
		data() {
			return {
				name: 'parent',
				age: 58,
				child: {
					name: 'child',
					age: 15,
				}
			};
		},
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += '<p>parent</p>';
			content += `<p>name = ${data.name}</p><p>age = ${data.age}</p>`;

			debugger;
			let view = this.$includeView('a', 'child', data.child);
			content += view.$getIndex();
			content += '</div>';

			debugger;
			this.$print(content);
		},
		$waiting() {
			this.$msgEl.innerHTML = 'parent loading...';
		},
		$done() {
			this.$msgEl.innerHTML = '';
		},
		changeAgeValue() {
			let pr = (async () => {
				debugger;
				let value = $randomValue(50, 100);
				this.$emit('waiting');

				await $bb.setTimeout(1000);

				this.$data.age = value;

				await this.$commit();
			})();
			//-------------
			pr.catch(err => {
				console.dir(err);
			});
			//-------------
			pr.finally(() => {
				debugger;
				console.log('render end');
			});

		},
		changeChild() {
			let pr = (async () => {
				debugger;
				let age = $randomValue(50, 100);
				let child = {
	        name: `child_${$childID++}`,
	        age,
	      };
				this.$emit('waiting');

				await $bb.setTimeout(1000);

				this.$data.child = child;

				await this.$commit();
			})();
			//-------------
			pr.catch(err => {
				console.dir(err);
			});
			//-------------
			pr.finally(() => {
				debugger;
				console.log('render end');
			});
		}
	}
	//-----------------------------
	const $options_1 = {
		el: 'div',
		$render() {
			debugger;
			const $shadow = this.$attachShadow();
			const data = this.$data;
			let content = '<p>child</p>';
			content += `<p>name = ${data.name}</p><p>age = ${data.age}</p>`;

			let dom = document.createElement('div');
			dom.innerHTML = content;
			$shadow.appendChild(dom);

			dom = document.createElement('button');
			dom.textContent = 'changeAgeValue';
			dom.addEventListener('click', ev => {
				debugger;
				this.changeAgeValue();
			});

			$shadow.appendChild(dom);
		},
		// callback
		$waiting(arg) {
			// console.dir(arg);
			let {target} = arg;

			if(!this.$isEqual(target)){
				return;
			}
			this.$msgEl.innerHTML = 'child loading...';
		},
		// callback
		$done(...args) {
			console.dir(args);
			this.$msgEl.innerHTML = '';
		},
		changeAgeValue() {

			let pr = (async () => {
				debugger;
				let value = $randomValue(50, 100);
				this.$emit('waiting');

				await $bb.setTimeout(1000);

				this.$data.age = value;

				await this.$commit();
			})();
			//-------------
			pr.catch(err => {
				console.dir(err);
			});
			//-------------
			pr.finally(() => {
				debugger;
				console.log('render end');
			});
		}
	};
	//-------------------
	$bb.view.add('parent', $options_0);
	$bb.view.add('child', $options_1);
})();
