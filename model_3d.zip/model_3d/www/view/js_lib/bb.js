debugger;
import $bb from '/my_modules/bb_core/index.js'
window['$bb'] = $bb;

import {
	handle as h_model
} from '/my_modules/model/index.js';
h_model($bb);

import {
	handle as h_view
} from '/my_modules/view/index.js';
h_view($bb);
