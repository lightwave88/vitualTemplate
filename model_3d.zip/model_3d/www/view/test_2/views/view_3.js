const $options_0 = {
  data() {
    let $data = {
      childs: [{
          name: 'x',
          age: 18,
        },
        {
          name: 'y',
          age: 50,
        }
      ]
    };

    return $data;
  },
  $render($m) {
    debugger;
    let data = $m.data;
    let content = '<div>head</div>';

    for (let i = 0; i < data.childs.length; i++) {
      debugger;
      let d = data.childs[i];
      d.index = i;
      let view = this.$includeView(d, 'child_1');
      debugger;
      content += view.$getIndex();
    }
    content += '<div>foot</div>';

    this.$print(content);
  }
}
//----------------------------
const $options_1 = {
  el: 'div',
  $render($m) {
    debugger;
    let data = $m.data;
    let content = '<div>';
    content += `<p>index = ${data.index}</p>`;
    content += `<p>name = ${data.name}</p>`;
    content += `<p>age = ${data.age}</p>`;
    content += '</div>';

    this.$print(content);
  }
};
//----------------------------
debugger;
// $bb.view.add('parent_1', $options_0);
$bb.view.add('child_1', $options_1);
