function test() {
  debugger;
  const $iter = $scope.getIter();
  const $data = $scope.getData();

  let $$_pNode;
  let $$_node;
  $$_node = $scope.createNode($$_pNode, "div", "div");
  $$_node.attr(null, { "class": "a" });
  $$_node.attr("both", { "class": ($data.className) });
  {
    const $$_pNode = $$_node;

    $$_node = $scope.createNode($$_pNode, "#text", null);
    $$_node.text("\n      hi ......\n    ");
  }
}