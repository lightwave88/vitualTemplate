debugger;

for (let i = 0; true; i++) {
  debugger;
  if (i > 3) {
    break;
  }
}


