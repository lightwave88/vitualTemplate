function t_1() {
  debugger;
  const $iter = $scope.getIter();
  const $data = $scope.getData();

  let $$_pNode;
  let $$_node;
  $$_node = $scope.createNode($$_pNode, "table", "table");
  {
    const $$_pNode = $$_node;

    $$_node = $scope.createNode($$_pNode, "#text", null);
    $$_node.text("\n      ");
    $$_node = $scope.createNode($$_pNode, "tbody", "tbody");
    {
      const $$_pNode = $$_node;

      $$_node = $scope.createNode($$_pNode, "#text", null);
      $$_node.text("\n        ");
      for (let [item, , i] of $iter($data.a)) {
        $$_node = $scope.createNode($$_pNode, "#text", null);
        $$_node.text("\n          ");
        if ((i % 2) == 0) {
          $$_node = $scope.createNode($$_pNode, "#text", null);
          $$_node.text("\n            ");
          $$_node = $scope.createNode($$_pNode, "tr", "tr");
          $$_node.attr("class", "a");
          {
            const $$_pNode = $$_node;

            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n              ");
            $$_node = $scope.createNode($$_pNode, "td", "td");
            {
              const $$_pNode = $$_node;

              $$_node = $scope.createNode($$_pNode, "#text", null);
              $$_node.text("\n                name = " + $scope.stringify(item.name) + "\n              ");
              $$_node = $$_pNode;
            }
            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n              ");
            $$_node = $scope.createNode($$_pNode, "td", "td");
            {
              const $$_pNode = $$_node;

              $$_node = $scope.createNode($$_pNode, "#text", null);
              $$_node.text("\n                age = " + $scope.stringify(item.age) + "\n              ");
              $$_node = $$_pNode;
            }
            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n            ");
            $$_node = $$_pNode;
          }
          $$_node = $scope.createNode($$_pNode, "#text", null);
          $$_node.text("\n          ");
        } else {
          $$_node = $scope.createNode($$_pNode, "#text", null);
          $$_node.text("\n            ");
          $$_node = $scope.createNode($$_pNode, "tr", "tr");
          $$_node.attr("class", "b");
          {
            const $$_pNode = $$_node;

            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n              ");
            $$_node = $scope.createNode($$_pNode, "td", "td");
            {
              const $$_pNode = $$_node;

              $$_node = $scope.createNode($$_pNode, "#text", null);
              $$_node.text("\n                name = " + $scope.stringify(item.name) + "\n              ");
              $$_node = $$_pNode;
            }
            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n              ");
            $$_node = $scope.createNode($$_pNode, "td", "td");
            {
              const $$_pNode = $$_node;

              $$_node = $scope.createNode($$_pNode, "#text", null);
              $$_node.text("\n                age = " + $scope.stringify(item.age) + "\n              ");
              $$_node = $$_pNode;
            }
            $$_node = $scope.createNode($$_pNode, "#text", null);
            $$_node.text("\n            ");
            $$_node = $$_pNode;
          }
          $$_node = $scope.createNode($$_pNode, "#text", null);
          $$_node.text("\n          ");
        }
        $$_node = $scope.createNode($$_pNode, "#text", null);
        $$_node.text("\n        ");
      } // for
      $$_node = $scope.createNode($$_pNode, "#text", null);
      $$_node.text("\n      ");
      $$_node = $$_pNode;
    }
    $$_node = $scope.createNode($$_pNode, "#text", null);
    $$_node.text("\n    ");
    $$_node = $$_pNode;
  }
}