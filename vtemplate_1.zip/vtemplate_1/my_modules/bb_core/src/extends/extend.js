let $bb;
const $extend = {};
//--------------------------------------
class TimeoutError extends Error {
	toString() {
		return 'timeoutError';
	}

	toJSON() {
		return 'timeoutError';
	}
}
////////////////////////////////////////////////////////////////////////////////
{
	// tools.getUid(namespace)
	//
	// 取得獨一無二的 id
	const $guid = {
		namespace: {},
		uid: 0,
		getUid(namespace = null) {

			if (namespace == null) {

			} else if (typeof(namespace) == 'string') {
				namespace = namespace.trim();
				namespace = (namespace.length > 0) ? namespace : null;
			} else if (typeof(namespace) == 'symbol') {

			} else {
				throw new TypeError('...');
			}

			if (namespace == null) {
				return this.uid++;
			}
			if (!(namespace in this.namespace)) {
				this.namespace[namespace] = 0;
			}
			return this.namespace[namespace]++;
		}
	};
	// API
	function getUid(namespace) {
		return $guid.getUid(namespace);
	}
	//------------------
	$extend.$getUid = getUid;
	$extend.getUid = getUid;
}
//------------------------------------------------------------------------------
{
	$extend.$isPlainObject = isPlainObject;
	$extend.isPlainObject = isPlainObject;
	//------------------
	const reg_1 = /^\[object Object\]$/;

	const proto_toString = Object.prototype.toString;
	const class2type = {};
	const class2typeCts = {}.constructor;
	const hasOwn = class2type.hasOwnProperty;

	// from jquery
	function isPlainObject(obj) {
		// debugger;
		let proto;
		let Ctor;
		let res;

		if (typeof obj != 'object') {
			return false;
		}
		// Detect obvious negatives
		// Use toString instead of jQuery.type to catch host objects
		res = proto_toString.call(obj);
		res = reg_1.test(res);

		if (!obj || !res) {
			return false;
		}
		proto = Object.getPrototypeOf(obj);

		// Objects with no prototype (e.g., `Object.create( null )`) are plain
		if (!proto) {
			return true;
		}
		// Objects with prototype are plain iff they were constructed by a global Object function
		Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

		return (typeof Ctor == "function" && Ctor === class2typeCts);
	}
}

//------------------------------------------------------------------------------
{
	$extend.$getClass = getClass;
	$extend.getClass = getClass;
	//------------------
	function getClass(data) {
		// debugger;
		const $toString = Object.prototype.toString;

		let _class = null;

		let str_1 = $toString.call(data);
		let res = /\[\w+\s+(\w+)\]/.exec(str_1);

		res = (res == null) ? [] : res;
		([, _class] = res);
		return _class;
	}
}
//------------------------------------------------------------------------------
{
	$extend.$timeout = timeout;
	$extend.timeout = timeout;

	function timeout(timeLimit, pr) {
		let to = new $TimeOut(timeLimit, pr);
		return to.promise;
	}
	//------------------
	class $TimeOut {
		$def;
		$timeHandle;
		//---------------------------------
		constructor(timeLimit, pr) {
			
			if (!(pr instanceof Promise)) {
				throw new TypeError('$bb.timeout(,pr) pr not instanceof Promise');
			}
			//---------------
			const def = this.$def = $bb.$deferred();

			// 計時器
			this.$timeHandle = setTimeout(() => {
				// debugger;
				def.reject(new TimeoutError());
				this._clear();
			}, timeLimit);
			//---------------
			pr.then((data) => {
				this._clear();
				def.resolve(data);
			}, (err) => {
				this._clear();
				def.reject(err);
			});
		}
		//---------------------------------
		get promise() {
			return this.$def.promise;
		}
		//---------------------------------
		_clear() {
			clearTimeout(this.$timeHandle);
			this.$timeHandle = null;
		}
	}
}
//------------------------------------------------------------------------------
{
	$extend.$setTimeout = $setTimeout;
	$extend.setTimeout = $setTimeout;
	//------------------
	// 事間到了會 resolve
	// setTimeout(null, time) 類似 sleep(time)
	function $setTimeout(time, fun = null) {
		if (fun != null && typeof(fun) != 'function') {
			throw new TypeError("$bb.detTimeout(, fun), fun must be function");
		}
		const $pr = new Promise(function($res, $rej) {
			setTimeout(() => {
				// debugger;
				let res;
				let er;
				let isFinsh = false;

				if (fun != null) {
					try {
						res = fun();
						isFinsh = true;
					} catch (_er) {
						er = _er;
					}
				} else {
					isFinsh = true;
				}
				//--------
				if (isFinsh) {
					$res(res);
				} else {
					$rej(er);
				}
			}, time);
		});
		return $pr;
	}
}
//------------------------------------------------------------------------------
{
	$extend.$promise = $promise;
	$extend.promise = $promise;
	//------------------
	function $promise(callback, context = null) {
		if (typeof(callback) != "function") {
			throw new TypeError("bb.promise(callback) callback must be function");
		}
		let fun;
		if (context != null) {
			fun = function(...args) {
				return callback.apply(context, args);
			};
		} else {
			fun = callback;
		}
		return new Promise(fun);
	}
}
//------------------------------------------------------------------------------
{
	$extend.$deferred = deferred;
	$extend.deferred = deferred;
	//------------------
	function deferred(timeout) {
		return new Deferred(timeout);
	}

	class Deferred {
		$handle;
		$pr;
		constructor(timeout = null) {

			this.$pr = new Promise(($res, $rej) => {
				this.$handle = (function*() {
					// debugger;
					let {
						error,
						data
					} = yield;

					// debugger;
					if (error == null) {
						$res(data);
					} else {
						$rej(error);
					}
				})();
				this.$handle.next();
			});
			//------------------
			// 計時器
			if (typeof timeout == 'number') {
				setTimeout(() => {
					this.$handle.next({
						error: (new TimeoutError()),
						data: null
					});
				}, timeout);
			}
		}
		//------------------------------------------------
		get promise() {
			return this.$pr;
		}
		//------------------------------------------------
		resolve(data) {
			this.$handle.next({
				error: null,
				data
			});
		}
		//------------------------------------------------
		reject(er) {
			this.$handle.next({
				error: er,
				data: null
			});
		}
	}
}
//------------------------------------------------------------------------------
{
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof(name) == 'symbol') {
			for (let [key, vale] of $bucket) {
				if (value === name) {
					res = key;
					break;
				}
			}
		} else if (typeof(name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
	//------------------
	// 系統內部共享的 symbol
	// tools.symbol(name)
	// 設定取得 symbol
	$extend.$symbol = $symbol;
	$extend.symbol = $symbol;
}
//------------------------------------------------------------------------------
export function handle(bb) {
	$bb = bb;

	for (let name in $extend) {
		if (name in $bb) {
			throw new Error(`${name} has exists`);
		}
		$bb[name] = $extend[name];
	}
	return $extend;
};
