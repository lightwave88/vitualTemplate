let $bb;

const $config = {
  // 爲所有 function 設置一個可辨識的 id
  functionIdAttrName: Symbol('bb_funId'),
};
//-----------------------
function config(...args) {
  let data = Object.assign({}, $config);

  let key;
  let value;
  switch (args.length) {
    case 0:
      value = data;
      break;
    case 1:
      key = args[0];
      value = data[key];
      break;
    case 2:
      key = args[0];
      value = args[1];
      $config[key] = value;
      return;
      break;
    default:
      throw new Error('$bb.config() args error');
      break;
  }
  return value;
}

function handle(bb) {
  $bb = bb;
  bb.$config = config;
}

export { handle };
