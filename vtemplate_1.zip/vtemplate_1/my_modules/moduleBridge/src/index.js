import {
	ModuleBridge,
	moduleBridge
} from './moduleBridge.js';

export {
	ModuleBridge,
	moduleBridge
};

export default ModuleBridge;
