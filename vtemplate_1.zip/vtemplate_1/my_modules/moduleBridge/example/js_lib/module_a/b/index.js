import {
  ModuleBridge
} from '../../moduleBridge.js';
const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_b
} from './b.js';

// 對外輸出 b
const $b = h_b($MB);
$MB.import('b', $b);
//-----------------------
import {
  handle as h_c
} from './c.js';

// c 只在此區塊可以看到
const $c = h_c($MB);
$MB.import('c', $c);
//-----------------------
function handle(mb) {
  debugger;

  // 對外連接
  $MB.linkParent(mb);

  // 對外輸出 b
  const b = $MB.get('b');
  return b;
}

export {
  handle
};
