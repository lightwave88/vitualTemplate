debugger;

let $MB;

const $a = {
  name: 'a',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//-------------
function onload() {
  console.log('a...')
  console.dir(this.modules());
  console.log('----------');
}
//-------------
function handle(mb) {
  debugger;
  $MB = mb;
  this.onload(onload);
  return $a;
}

export {
  handle
};
