// debugger;

import MB from './mb.js';
const $mb = new MB();
//-------------

import m_tools from './tools/index.js';
$mb.importModule('tools', m_tools);

//-------------
import m_compile from './compile/index.js';
$mb.importModule('Compile', m_compile);

//-------------
import {
  handle as h_cdAttr
} from './commandAttr.js';
$mb.importHandle('CommandAttr', h_cdAttr);

//-------------
// debugger;
import m_cpAttr from './computeAttr/index.js';
$mb.importModule('CpAttrSolution', m_cpAttr);
//-------------
import {
  handle as h_cScope
} from './compileScope.js';
$mb.importHandle('CompileScope', h_cScope);
//-------------
import {
  handle as h_invoke
} from './invoke.js';
$mb.importHandle('Invoke', h_invoke);

//-------------
import {
  handle as h_vnode
} from './vnode.js';
$mb.importHandle('VNode', h_vnode);
//-------------
import {
  handle as h_api
} from './api.js';
$mb.importHandle('api', h_api);
//-------------
import m_patch from './patch/index.js'
$mb.importModule('Patch', m_patch);
//-------------
import { handle as h_matchNode } from './matchNodeTest.js'
$mb.importHandle('MatchNode', h_matchNode);
//-------------
export function handle(bb) {
  $mb.import('bb', bb);
  const api = $mb.get('api');
  bb['vTemplate'] = api;
}
