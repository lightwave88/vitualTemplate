let $MB;

const $api = {

  // args = {include,}
  compile(dom, args = {}) {
    debugger;

    if(typeof(dom) == 'string'){
      dom = document.querySelector(dom);
    }

    if (dom == null) {
      throw new Error('...');
    }
    dom.remove();

    const Compile = $MB.get('Compile');
    let cpl = Compile.create(dom, args);
    let render = cpl.main();

    return render;
  },
  //-----------------------
  patch(newNode, oldNode, dom = null){
    debugger;
    const VNode = $MB.get('VNode');
    const Patch = $MB.get('Patch');
    let patch = Patch.create();
    
    if(oldNode instanceof HTMLElement){
      oldNode = VNode.getVnode(oldNode);
    }

    patch.main(newNode, oldNode, dom);
  },
  //-----------------------
  // 增加計算屬性的解析方式
  addComputeAttr(attrName, callback){
    // callback 輸入 class CAttr
    // 輸出 class
  },
  //-----------------------
  matchDom(dom, oldDom){
    const MatchNode = $MB.get('MatchNode');
    let analyze = new MatchNode(dom, oldDom);
    analyze.main();
  }
}

export function handle(mb) {
  $MB = mb;
  return $api;
}
