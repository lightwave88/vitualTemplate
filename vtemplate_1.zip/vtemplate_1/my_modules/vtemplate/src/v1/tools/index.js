import MB from '../mb.js';
const $MB = new MB();
//-----------------------
import {
  handle as h_tools
} from './tools.js';
$MB.importHandle('tools', h_tools);
//-----------------------
import {
  handle as h_makeIterator
} from './iterator.js';
$MB.importHandle(h_makeIterator);
//-----------------------
$MB.export(function() {
  const tools = this.get('tools');
  return tools;
});

export default $MB;
