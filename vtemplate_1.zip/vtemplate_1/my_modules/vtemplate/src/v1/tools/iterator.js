let $MB;

class Iterator {
  $data;
  $dataClass;
  $begin = 0;
  $step = 1;
  $end;
  $isIterable;
  //----------------------------
  constructor(data) {
    // debugger;
    this.$data = data;
  }
  //----------------------------
  // 設置 loop 選項
  setArgs(args = {}) {
    let {
      begin = null, end = null, step = null
    } = args;
    if (begin != null)
      this.begin = begin;
    if (end != null)
      this.$end = end;
    if (step != null)
      this.$step = step;
  }
}
/////////////////////////////////////////////
// 沒有設置 iterator 的 {}
class ObjectIterator extends Iterator {

  *[Symbol.iterator]() {
    // debugger;

    const $data = this.$data;

    let keys = Object.getOwnPropertyNames($data);
    //-------------
    for (let i = 0; i < keys.length; i++) {
      // debugger;
      if (this.$end != null && j > this.$end) {
        break;
      }
      if (i % this.$step != 0) {
        continue;
      }
      let key = keys[i];
      let value = $data[key];

      // 斷點
      yield [value, key, i];
    } // for
    //-------------
  }
}
/////////////////////////////////////////////
class DefaultIterator extends Iterator {
  *[Symbol.iterator]() {
    const $data = this.$data;

    let i = 0;

    for (let entry of $data) {
      const j = i++;
      if (this.$end != null && j > this.$end) {
        break;
      }
      if (j % this.$step != 0) {
        continue;
      }
      let value = entry;
      let key = j;

      yield [value, key, j];
    } // for
  }
}
/////////////////////////////////////////////
// Map
class MapIterator extends Iterator {
  *[Symbol.iterator]() {
    const $data = this.$data;

    let i = 0;

    for (let entry of $data) {
      // debugger;
      const j = i++;

      if (this.$end != null && j > this.$end) {
        break;
      }
      if (j % this.$step != 0) {
        continue;
      }
      let [value, key] = entry;

      yield [value, key, j];
    } // for
  }
}
/////////////////////////////////////////////
// for [], Set
class ListIterator extends Iterator {
  *[Symbol.iterator]() {
    const $data = this.$data;

    let i = 0;

    for (let entry of $data) {
      // debugger;
      const j = i++;

      if (this.$end != null && j > this.$end) {
        break;
      }
      if (j % this.$step != 0) {
        continue;
      }
      let value = entry;
      let key = j;

      yield [value, key, j];

    } // for
  }
}
/////////////////////////////////////////////
// 是否能 loop
function isIterable(data) {
  // checks for null and undefined
  if (data == null) {
    return false;
  }
  return (typeof(data[Symbol.iterator]) === 'function');
}
//----------------------------
// API
function makeIterator(data, options = {}) {
  // debugger;

  const $tools = $MB.get('tools');
  const isObject = (typeof(data) == 'object');

  let node;

  if (!isObject) {

    if (!isIterable(data)) {
      let type = typeof(data);
      throw new TypeError(`data(${JSON.stringify(data)}) type(${type}) cant iterator`);
    }

    node = new DefaultIterator(data);
  } else {

    if (!isIterable(data)) {
      node = new ObjectIterator(data);
    } else {
      const className = $tools.getClass(data);

      switch (className) {
        case '[object Map]':
          node = new MapIterator(data);
          break;
        case '[object Set]':
        case '[object Array]':
          node = new ListIterator(data);
          break;
        case '[object Object]':
          node = new ObjectIterator(data);
          break;
        default:
          throw new TypeError(`no support type(${className})`);
          break;
      }
    }
  }
  node.setArgs(options);
  return node;
}
//----------------------------
export function handle(mb) {
  $MB = mb;

  const $tools = mb.get('tools');
  $tools.makeIterator = makeIterator;
}
