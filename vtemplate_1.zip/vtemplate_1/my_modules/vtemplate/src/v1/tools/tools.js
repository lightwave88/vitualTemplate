let $MB;
const $tools = {};
//---------------------------------
{
  // {{...}}
  const $reg_1 = /\{\{([^]*?)\}\}/;

  $tools.splitVar = function (text) {
    // debugger;

    let reg_1 = RegExp($reg_1, 'gm');

    let contentList = [];
    let reg_res;

    let end = 0;
    let length = text.length;

    let hasVar = false;

    let content;
    while ((reg_res = reg_1.exec(text)) != null) {
      // debugger;
      hasVar = true;

      let start = reg_res.index;

      if (start > end) {
        content = text.substring(end, start);
        content = JSON.stringify(content);
        contentList.push(content);
      }
      end = reg_1.lastIndex;
      //-------------
      content = reg_res[1];
      content = `$scope.stringify(${content})`;
      contentList.push(content);
    } // while
    //--------
    if (length > end) {
      content = text.substring(end);
      content = JSON.stringify(content);
      contentList.push(content);
    }
    //--------
    content = contentList.join('+');
    return {
      hasVar,
      content
    };
  };
}
//---------------------------------
{
  $tools.checkRootDom = function (dom, isInclude) {
    let check = new CheckRootDom(dom, isInclude);
    return check.main();
  };

  class CheckRootDom {
    $dom;
    $tagName;
    $isInclude;
    //-------------
    constructor(dom, isInclude) {
      this.$dom = dom;
      this.$isInclude = isInclude;

      if (this.$dom.tagName == null) {
        throw new Error('...');
      }
      this.$tagName = dom.tagName.toLowerCase();
    }
    //-------------
    main() {
      // debugger;

      let rootDom;
      switch (this.$tagName) {
        case 'template':
          this.$isInclude = false;
          let dom = this.$dom.content;
          if (dom.children.length > 1) {
            throw new Error('...');
          }
          rootDom = dom.children[0];
          break;
        default:
          if (this.$isInclude) {
            rootDom = this.$dom;
          } else {
            let dom = this.$dom;
            if (dom.children.length > 1) {
              throw new Error('...');
            }
            rootDom = dom.children[0];
          }
          break;
      } // switch

      if (rootDom == null) {
        throw new Error('...');
      }
      return rootDom;
    }
    //-------------
  }
}
//---------------------------------
{
  // 解析 b-for
  $tools.analyzeBFor = function (text) {
    let arg = p_1(text);

    let content = p_2(arg);

    return content;
  };
  //------------------
  const $iterFunName = '$iter';

  const $reg_1 = /^([^]+?)in\s+(\S+)\s*$/;

  // 去除 ()
  const $reg_2 = /\(\s*|\s*\)/;

  const $reg_3 = /\s*,\s*/;

  function p_1(text) {
    debugger;

    let reg_res = $reg_1.exec(text);
    let {
      1: vars,
      2: dataName,
    } = reg_res;

    const reg_2 = RegExp($reg_2, 'g');
    vars = vars.replace(reg_2, '');

    const reg_3 = RegExp($reg_3, 'g');
    vars = vars.split(reg_3);

    let [valueName, keyName = null, indexName = null] = vars;

    debugger;
    return {
      dataName,
      valueName,
      keyName,
      indexName
    };
  }
  //------------------
  function p_2(arg) {
    debugger;

    let {
      dataName
    } = arg;
    delete (arg['dataName']);
    /*
    let {
      valueName,
      keyName,
      indexName
    } = arg;
    */
    let contentList = Object.values(arg);

    contentList = contentList.filter((text) => {
      return (text != null);
    });

    contentList = contentList.map((text) => {
      return text.trim();
    });

    let content = contentList.join(',');
    content = `for(let [${content}] of ${$iterFunName}(${dataName})) {`;

    return content;
  }
}
//---------------------------------
{
  $tools.stringify = function (value, filters = []) {
    debugger;
    let res;
    if (typeof (value) == 'object') {
      if (value == null) {
        if (typeof value == 'undefined') {
          res = 'undefined';
        } else {
          res = 'null';
        }
      } else {
        res = JSON.stringify(value);
      }
    } else {
      res = '' + value;
    }
    return res;
  }
}
//---------------------------------
{
  $tools.getClass = function (data) {
    return toString(data);
  };

  function toString(data) {
    return Object.prototype.toString.call(data);
  }
}
//---------------------------------
export function handle(mb) {
  $MB = mb;
  return $tools;
}
