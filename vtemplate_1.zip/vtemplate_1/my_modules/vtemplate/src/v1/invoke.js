let $MB;

// vnode 的事件綁定
class Invoke {
  $dom;
  $value;
  $eventName;
  $callback;
  //-------------
  constructor(dom, eventName) {
    this.$dom = dom;
    this.$eventName = eventName;

    this.$callback = (e) => {
      let res = this.$value(e);
    };

    this.$dom.addEventListener(this.$eventName, this.$callback);
  }
  //-------------
  // API
  static create(dom, eventName) {
    return new Invoke(dom, eventName);
  }
  //-------------
  set value(value) {
    if (typeof(value) != 'function') {
      throw new TypeError('...');
    }
    this.$value = value;
  }

  get value() {
    return this.$value;
  }
  //-------------
  remove() {
    this.$dom.removeEventListener(this.$eventName, this.$callback);
    this._destory();
  }
  //-------------
  _destory() {
    for (let key in this) {
      if (Object.hasOwnProperty.call(this, key)) {
        this[key] = undefined;
        delete(this[key]);
      }
    }
  }
  //-------------
}

export function handle(mb) {
  $MB = mb;
  return Invoke;
}
