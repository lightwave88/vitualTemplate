let $MB;

// input
const $inputDomList = [];

// 處理 b-model="..."
// 綁定事件
// 設置 prop
class BModel {
  $varName;
  //------------------
  constructor(varName) {
    this.$varName = varName;
  }
  //------------------
  // API
  print() {
    // ovrride
  }
  //------------------
  static isMatch(nodeName, attrs) {
    // ovrride
  }
}
/////////////////////////
class Select extends BModel {

}

$checkClassList.push(Select);
/////////////////////////

const $b_model = {
  getAnalyze(attrs, nodeName, varName) {

    let $class;
    let node;
    switch (nodeName) {
      case 'select':
        $class = Select;
        break;
      case 'input':

        break;
      default:
        break;
    } // switch
    //-------------
    if ($class != null) {
      node = new $class(varName);
    }
    return node;
  }
}

export function handle(mb) {
  $MB = mb;
  return $b_model;
}
