let $MB;

class MatchNode {
  $dom;
  $oldDom;
  //------------------
  constructor(dom, oldDom) {
    this.$dom = dom;
    this.$oldDom = oldDom;
  }
  //------------------
  main() {

  }
}

export function handle(mb) {
  $MB = mb;
  return MatchNode;
}