let $MB;

const $commandAttrs = new Set([
  'b-if',
  'b-if-else',
  'b-else',
  'b-for'
]);

const $reg_1 = /^b-\w/;
// const $reg_2 = /^template$/;

class CommandAttr {
  $dom;
  $tagName;
  //-----------------------
  constructor(dom) {
    this.$dom = dom;
    this.$tagName = dom.tagName.toLowerCase();
  }
  //-----------------------
  // API
  main() {
    throw new Error('need override');
  }
  //-----------------------
  _isTemplate() {
    return (this.$tagName == 'template');
  }
  //-----------------------
  // API
  static getAttrNames() {
    return new Set($commandAttrs);
  }
  //-----------------------
  // API
  // 根據 attrName 取得解
  static getSolution(attrName, dom) {
    let node;
    switch (attrName) {
      case 'b-if':
        node = new BIf(dom);
        break;
      case 'b-if-else':
        node = new BIfElse(dom);
        break;
      case 'b-else':
        node = new BElse(dom);
        break;
      case 'b-for':
        node = new BFor(dom);
        break;
      default:
        throw new TypeError(`no support this attr(${attrName})`);
        break;
    } //switch
    //-------------
    return node;
  }
  //-----------------------
  // API
  static checkAttrs(dom) {
    debugger;

    // 確認是否有 b-XX
    // 若有，就進入 this.getSolution(...)處理
    let attrs = Array.from(dom.attributes);

    let cAttr;
    // let attrValue;
    for (let i = 0; i < attrs.length; i++) {
      debugger;
      let {
        name,
        // value
      } = attrs[i];

      if ($reg_1.test(name) && $commandAttrs.has(name)) {
        cAttr = name;
        let solution = this.getSolution(cAttr, dom);
        solution.main();
      }
    } // for

  }
  //-----------------------
}
//////////////////////////////
class BIf extends CommandAttr {
  $attrName = 'b-if';
  //-----------------------
  main() {
    debugger;

    // this._checkBrothers()
    //-------------
    const $dom = this.$dom;

    let parent = $dom.parentNode;
    let nextDom = $dom.nextSibling;

    let value = $dom.getAttribute(this.$attrName);
    value = value.trim();

    $dom.removeAttribute(this.$attrName);
    //--------
    let script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = `\nif(${value}) {`;

    parent.insertBefore(script, $dom);
    //--------
    script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = '\n}';
    parent.insertBefore(script, nextDom);
  }
  //-----------------------
  _checkBrothers() {
    debugger;
    let dom = this.$dom;

    // 往後檢查
    while (true) {
      let next = dom.nextSibling;
      if (next == null) {
        break;
      } else if (next.tagName == null) {
        next.remove();
        next = dom;
      } else {
        if (next.hasAttribute('b-if-else') || next.hasAttribute('b-else')) {
          break;
        } else {
          throw new Error('...');
        }
      }
      dom = next;
    }
  }
}
//////////////////////////////

class BIfElse extends CommandAttr {
  $attrName = 'b-else-if';
  $reg_1 = /^script$/i;
  //-----------------------
  main() {
    debugger;

    this._checkBrothers();
    //-------------
    const $dom = this.$dom;

    let parent = $dom.parentNode;
    let nextDom = $dom.nextSibling;

    let value = $dom.getAttribute(this.$attrName);
    value = value.trim();

    $dom.removeAttribute(this.$attrName);
    //--------
    let script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = ` else if(${value}) {`;

    parent.insertBefore(script, $dom);
    //--------
    script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = '\n}';
    parent.insertBefore(script, nextDom);
  }
  //-----------------------
  _checkBrothers() {
    debugger;
    let dom = this.$dom;

    // 往前檢查
    while (true) {
      let previous = dom.previousSibling;
      if (previous == null) {
        throw new Error('...');
      } else if (previous.tagName == null) {
        previous.remove();
        previous = dom;
      } else {
        if (this.$reg_1.test(previous.tagName)) {
          break;
        } else {
          throw new Error('...');
        }
      }
      dom = previous;
    }
    //-------------
    dom = this.$dom;
    // 往後檢查
    while (true) {
      let next = dom.nextSibling;
      if (next == null) {
        break;
      } else if (next.tagName == null) {
        next.remove();
      } else {
        if (next.hasAttribute('b-if-else') || next.hasAttribute('b-else')) {
          break;
        } else {
          throw new Error('...');
        }
      }
      dom = next;
    }
  }
}
//////////////////////////////
class BElse extends CommandAttr {
  $attrName = 'b-else';
  $reg_1 = /^script$/i;
  //-----------------------
  main() {
    debugger;
    this._checkBrothers();
    //-------------
    const $dom = this.$dom;

    let parent = $dom.parentNode;
    let nextDom = $dom.nextSibling;

    $dom.removeAttribute(this.$attrName);
    //--------
    let script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = ' else {';

    parent.insertBefore(script, $dom);
    //--------
    script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = '\n}';
    parent.insertBefore(script, nextDom);
  }
  //-----------------------
  _checkBrothers() {
    debugger;
    // 往前檢查

    let dom = this.$dom;

    while (true) {
      let previous = dom.previousSibling;
      if (previous == null) {
        throw new Error('...');
      } else if (previous.tagName == null) {
        previous.remove();
        previous = dom;
      } else {
        if (this.$reg_1.test(previous.tagName)) {
          break;
        } else {
          throw new Error('...');
        }
      }
      dom = previous;
    }
  }
}
//////////////////////////////
class BFor extends CommandAttr {
  $iterFunName = '$iter';
  $reg_1 = /^([^]+?)\s+of\s+(\S+)\s*$/;

  // 去除 ()
  $reg_2 = /\[\s*|\s*\]/;

  $reg_3 = /\s*,\s*/;
  //-----------------------
  main() {
    debugger;

    const $dom = this.$dom;

    let parent = $dom.parentNode;
    let nextDom = $dom.nextSibling;

    let value = $dom.getAttribute('b-for');
    value = value.trim();

    $dom.removeAttribute('b-for');

    // 把 b-for 內容解析成正確命令
    value = this._analyzeBFor(value);

    let script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = '\n' + value;

    parent.insertBefore(script, $dom);
    //--------
    script = document.createElement('script');
    script.setAttribute('type', 'text/template');
    script.innerHTML = '}';
    parent.insertBefore(script, nextDom);
  }
  //-----------------------
  _analyzeBFor(text) {
    debugger;

    const reg_1 = RegExp(this.$reg_1);

    let reg_res = reg_1.exec(text);

    if (reg_res == null) {
      throw new Error('...');
    }
    console.dir(reg_res);

    let {
      1: vars,
      2: dataName,
    } = reg_res;

    const reg_2 = RegExp(this.$reg_2, 'g');
    vars = vars.replace(reg_2, '');

    const reg_3 = RegExp(this.$reg_3, 'g');
    vars = vars.split(reg_3);

    vars = vars.filter((text) => {
      return (text != null);
    });
    vars = vars.map((text) => {
      return text.trim();
    });

    let content = vars.join(',');
    content = `for(let [${content}] of ${this.$iterFunName}(${dataName})) {`;

    return content;
  };
  //------------------
}
//////////////////////////////

export function handle(mb) {
  $MB = mb;
  return CommandAttr;
}
