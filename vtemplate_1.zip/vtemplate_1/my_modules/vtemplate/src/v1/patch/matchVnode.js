let $MB;

// 搜索匹配 node
class MatchNode {
  $nodes;
  $oldNodes;
  //------------------
  constructor(nodes, oldNodes) {
    this.$nodes = nodes;
    this.$oldNodes = oldNodes;
  }
  //------------------
  main() {
    let childs = this.$nodes;
    let oldChilds = this.$oldNodes;

    const $matchList = [];
    let $oldChilds = new Set(oldChilds)

    for (let i = 0; i < childs.length; i++) {
      debugger;
      let node = childs[i];
      let match = this._findNode(node, $oldChilds);
      $matchList.push({
        newNode: node,
        oldNode: match,
      });
    }
    return $matchList;
  }
  //------------------
  // 找尋 match
  _findNode(target, nodes) {
    debugger;
    let match;

    for (let node of nodes) {
      debugger;
      let res = target.isSameType(node);

      debugger;
      if (res) {
        match = node;
        nodes.delete(node);
        break;
      }
    }
    return (match || null);
  }
  //------------------
}

export function handle(mb) {
  $MB = mb;
  return MatchNode;
};