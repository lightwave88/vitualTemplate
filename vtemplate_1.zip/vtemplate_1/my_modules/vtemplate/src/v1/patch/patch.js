let $MB;

class Patch {
  constructor() { }
  //-----------------------
  static create() {
    return new Patch();
  }
  //-----------------------
  main(newNode, oldNode, rootDom = null) {
    debugger;
    if (newNode == null) {
      oldNode.remove();
      return;
    }
    //--------
    let $checkList = [];

    $checkList.push({
      newNode: newNode,
      oldNode: oldNode,
    });
    //-------------
    // vnode 配對
    for (let i = 0; true; i++) {
      debugger;

      let d = $checkList[i];
      if (d == null) {
        break;
      }

      let {
        newNode,
        oldNode,
      } = d;
      //-------------
      // 建構 dom
      debugger;
      if (newNode == null && oldNode == null) {
        continue;
      } else if (newNode == null) {
        oldNode.remove();
      } else if (oldNode == null) {
        newNode.buildDom(oldNode);
      } else {
        newNode.buildDom(oldNode);
      }
      //-------------
      debugger;
      // about childs
      let childs = newNode.$childs;
      let oldChilds = (oldNode == null) ? [] : oldNode.$childs;

      // 配對
      let list = this._matchNodes(childs, oldChilds);

      debugger;
      while (list.length > 0) {
        debugger;
        let {
          newNode,
          oldNode,
        } = list.shift();

        $checkList.push({
          newNode,
          oldNode,
        });
      } // while
    } // for
    //-------------
    let dom = newNode.getDom();

    if (rootDom != null) {
      rootDom.appendChild(dom);
      return;
    }
    return dom;
  }
  //-----------------------
  // 處理 childs
  // 難處
  // 難處
  _matchNodes(childs, oldChilds) {
    debugger;
    const MatchNode = $MB.get('MatchNode');

    const matchNode = new MatchNode(childs, oldChilds);

    let matchList = matchNode.main();

    return matchList;
  }
  //-----------------------
}
///////////////////////////////////
export function handle(mb) {
  $MB = mb;
  return Patch;
}
