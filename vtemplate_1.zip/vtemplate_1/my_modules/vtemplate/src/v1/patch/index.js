import $MB from '../mb.js'
const $mb = new $MB;
//------------------
import { handle as h_mv } from './matchVnode.js';
$mb.importHandle('MatchNode', h_mv);
//------------------
import { handle as h_patch } from './patch.js';
$mb.importHandle('Patch', h_patch);
//------------------
$mb.export(function () {
  let Patch = this.get('Patch');
  return Patch;
});