import MB from '../mb.js';
const $mb = new MB();
//-----------------------
import {
  handle as h_cnode
} from './cnode.js';
$mb.importHandle('cnode', h_cnode);
//-----------------------
import {
  handle as h_compile
} from './compile.js';
$mb.importHandle('Compile', h_compile);
//-----------------------
$mb.export(function() {
  // debugger;
  let Compile = this.get('Compile');
  return Compile;
});

export default $mb;
