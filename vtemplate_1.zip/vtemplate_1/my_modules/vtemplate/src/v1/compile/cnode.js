let $MB;

const $modelAttr = 'b-model';
const $reg_2 = /^(\w*\:|@)(\w[^]+)$/;
const $nodeName = '$$_node';
const $nodeParentName = '$$_pNode';

// for compile
class CNode {
  $dom;
  //--------
  $parent;
  $childs = [];
  //--------
  $nodeName;
  $tagName;
  //--------
  $attrs = {};

  // dom.prop, dom.attr
  $c_attrs = {};

  // dom.prop
  $p_attrs = {};

  // dom.attr
  $a_attrs = {};
  //--------
  $events = {};
  //--------
  // $content = '';
  //------------------
  constructor(dom, nodeName, parent = null) {
    // debugger;

    this.$dom = dom;
    this.$nodeName = nodeName;
    if (parent != null) {
      this.$parent = parent;
      this.$parent.addChild(this);
    }
    if ('tagName' in dom) {
      let tagName = dom['tagName'];
      this.$tagName = tagName.toLowerCase();
    }
  }
  //------------------
  // API
  static createNode(dom, parent) {
    return $createNode(dom, parent);
  }
  //------------------
  get dom() {
    return this.$dom;
  }
  //------------------
  getChilds() {
    let list = Array.from(this.$dom.childNodes);
    return list;
  }
  //------------------
  addChild(cnode) {
    this.$childs.push(cnode);
  }
  //------------------
  // API
  print() {
    throw new Error('...');
  }
  //------------------
  t_getHead() {

    let tagText = (this.$tagName == null) ? 'null' : JSON.stringify(this.$tagName);
    let content = `\n${$nodeName} = $scope.createNode(${$nodeParentName}, "${this.$nodeName}", ${tagText});`;
    return content;
  }
  //------------------
  // tools
  // 分離 attr
  t_analyzeAttr(dom) {
    // debugger;
    let attrs = Array.from(dom.attributes);

    let $events = {};
    let $attrs = {};
    let $c_attrs = {};
    let $p_attrs = {};
    let $a_attrs = {};

    while (attrs.length > 0) {
      // debugger;
      let attr = attrs.pop();
      let {
        name,
        value
      } = attr;

      const reg_res = $reg_2.exec(name);
      if (reg_res != null) {
        // 計算 attr
        let {
          1: g1,
          2: g2,
        } = reg_res;

        value = value.trim();

        switch (g1) {
          case '@':
            $events[g2] = value;
            break;
          case ':':
            $c_attrs[g2] = value;
            break;
          case 'a:':
            $a_attrs[g2] = value;
            break;
          case 'p:':
            $p_attrs[g2] = value;
            break;
          default:
            throw new Error('...');
            break;
        }
      } else {
        // 一般 attr
        $attrs[name] = value;
      }
    } // while
    //-------------
    // debugger;
    // 檢查
    // $c_attrs, $p_attrs, $a_attrs 的 key 不能重複
    let checkKeys = new Set();
    let checkList = [$c_attrs, $p_attrs, $a_attrs];

    while (checkList.length > 0) {
      let attrs = checkList.pop();
      let keys = Object.keys(attrs);
      while (keys.length > 0) {
        let key = keys.pop();

        if (checkKeys.has(key)) {
          throw new Error(`attr(${key}) has set before`);
        } else {
          checkKeys.add(key);
        }
      }
    }
    //-------------
    this.$events = $events;
    this.$attrs = $attrs;
    this.$c_attrs = $c_attrs;
    this.$p_attrs = $p_attrs;
    this.$a_attrs = $a_attrs;
  }
  //------------------
  // tools
  t_checkAttrs($attrs) {
    // debugger;

    const $tools = $MB.get('tools');

    let vars = [];

    for (let key in $attrs) {

      let value = $attrs[key];
      let {
        hasVar,
        content
      } = $tools.splitVar(value);

      content = hasVar ? `(${content})` : content;
      vars.push(`"${key}": ${content}`);

      delete($attrs[key]);
    }
    vars = vars.join(',\n');

    let content = `\n${$nodeName}.attr(null, {${vars}});`;

    return content;
  }
  //------------------
  // tools
  t_checkCAttrs(type, $attrs) {
    // debugger;
    let vars = [];

    for (let key in $attrs) {
      // 是表達式
      let value = $attrs[key];
      vars.push(`"${key}": (${value})`);
      delete($attrs[key]);
    }
    vars = vars.join(',\n');

    let content = `\n${$nodeName}.attr("${type}", {${vars}});`;
    return content;
  }
  //------------------
  // tools
  t_checkEvents($events) {
    // debugger;

    let content = [];

    for (let name in $events) {
      let funName = $events[name];
      let fun = `(e)=>{this.${funName})(e);}`;
      content.push(`\n${$nodeName}.event("${key}", ${fun});`);

      delete($events[name]);
    }
    return content.join('');
  }
  //------------------
  t_checkSpecAttrs() {
    // b-model
  }
  //------------------
  // b-model
  // 綁定事件
  // 設置 prop
  t_checkModel() {
    // debugger;

    if (!($modelAttr in $attrs)) {
      return;
    }
    const b_model = $MB.get('b_model');
    let value = this.$c_attrs[$modelAttr];

    // 取得分析模組
    let analyze = b_model.getAnalyze(this.$attrs, this.$nodeName, value);
    if (analyze == null) {
      return;
    }

    let content = analyze.print();

    // debugger;
    return content;
  }
  //------------------
  t_removeChilds() {
    let doms = Array.from(this.$dom.childNodes);

    while (doms.length > 0) {
      let dom = doms.shift();
      dom.remove();
    }
  }
}
//////////////////////////////
class DefaultNode extends CNode {
  constructor(dom, nodeName, parent) {
    super(dom, nodeName, parent);
  }
  //------------------
  // API
  print() {
    // debugger;

    let content = [];
    //-------------
    // childs
    // 關於 childs 的設定
    if (this.$childs.length > 0) {
      content.push(`\n{\nconst ${$nodeParentName}=${$nodeName};\n`);

      this.$childs.forEach((cnode) => {
        // debugger;
        let text = cnode.print();
        content.push(text);
      });

      // content.push(`\n${$nodeName}=${$nodeParentName};`);
      content.push('\n}');
    }
    //-------------
    // debugger;
    // self
    // 關於自己的設定
    // debugger;
    let text = this._getSelfContent();
    content.unshift(text);
    //-------------
    // root
    if (this.$parent == null) {
      text = `\nlet ${$nodeParentName};\nlet ${$nodeName};`;
      content.unshift(text);
    }
    // debugger;
    content = content.join('');
    return content;
  }
  //------------------
  _getSelfContent() {
    // debugger;

    const $dom = this.$dom;

    let list = [];

    let text = this.t_getHead();
    list.push(text);

    if (this.$tagName == null) {
      text = this._checkText($dom.textContent);
      list.push(text);
    } else {
      // debugger;

      // 分析 attr
      this.t_analyzeAttr($dom);

      // 一般 attr
      text = this.t_checkAttrs(this.$attrs);
      list.push(text);

      // debugger;

      // 計算 attr
      let checkList = {
        'both': this.$c_attrs,
        'prop': this.$p_attrs,
        'attr': this.$a_attrs
      };
      //--------
      for (let type in checkList) {
        // debugger;
        let attrs = checkList[type];

        if(Object.keys(attrs).length > 0){
          text = this.t_checkCAttrs(type, attrs);
          list.push(text);
        }
      }
      //--------
      text = this.t_checkEvents(this.$events);
      list.push(text);
    }
    // debugger;
    let content = list.join('');
    return content;
  }
  //------------------
  _checkText(text) {
    // debugger;
    const $tools = $MB.get('tools');

    let {
      hasVar,
      content
    } = $tools.splitVar(text);

    content = hasVar ? `(${content})` : content;

    content = `\n${$nodeName}.text(${content});`;
    return content;
  }
  //------------------
}
//////////////////////////////
class ScriptNode extends CNode {

  constructor(dom, nodeName, parent) {
    super(dom, nodeName, parent);
  }
  //------------------
  getChilds() {
    // 去除他的子 dom
    return [];
  }
  //------------------
  print() {
    debugger;
    let content = this.$dom.textContent;

    this.t_removeChilds();

    return content;
  }
  //------------------
}
//////////////////////////////
class B_viewNode extends CNode {
  //------------------
  constructor(dom, nodeName, parent) {
    debugger;
    super(dom, nodeName, parent);
  }
  //------------------
  getChilds() {
    return [];
  }
  //------------------
  print() {
    const $tools = $MB.get('tools');

    let content = this.t_getHead();
    {
      let {
        attrs
      } = this.t_analyzeAttr(this.$dom);
      Object.assign(this.$attrs, attrs);
    }
    //--------
    {
      // 子節點
      let {
        attrs,
        cAttrs,
      } = this._checkParams();

      Object.assign(this.$attrs, attrs);
      Object.assign(this.$c_attrs, cAttrs);
    }
    //--------
    /*
    for (let name in this.$attrs) {
      let value = this.$attrs[name];
      value = $tools.splitVar(value);
      content += `\n{$nodeName}.attr("${name}", value);`;
    }

    for (let name in this.$c_attrs) {
      let value = this.$c_attrs[name];
      content += `\n{$nodeName}.cAttr("${name}", ${value};`;
    }
    content += `\n${$nodeName}.loadView();`;
    */
    return content;
  }
  //------------------
  _checkParams() {
    let childs = Array.from(this.$dom.childNodes);

    let $attrs = {};
    let $cAttrs = {};

    while (childs.length > 0) {
      let dom = childs.shift();

      let {
        attrs = null,
          cAttrs = null,
      } = this.t_analyzeAttr(dom);

      Object.assign($attrs, attrs);
      Object.assign($cAttrs, cAttrs);
    } // while

    this.t_removeChilds();

    return {
      attrs: $attrs,
      cAttrs: $cAttrs,
    };
  }
  //------------------
}
//////////////////////////////
// API
function $createNode(dom, parent) {
  // debugger;

  let nodeName = dom.nodeName.toLowerCase();

  let node;
  switch (nodeName) {
    case 'script':
      node = new ScriptNode(dom, nodeName, parent);
      break;
    case 'b-view':
      node = new B_viewNode(dom, nodeName, parent);
      break;
    default:
      node = new DefaultNode(dom, nodeName, parent);
      break;
  }
  return node;
}

export function handle(mb) {
  $MB = mb;
  return CNode;
}
