let $MB;

const $reg_1 = /\[%([\s\S]*?)%\]/;

class Compile {
  $args = {};
  $rootDom;
  $scriptContent = new Map();
  //-----------------------
  constructor(dom, args = {}) {
    debugger;
    const $tools = $MB.get('tools');

    Object.assign(this.$args, args);

    let { include = true } = this.$args;

    // 選擇適當的 rootDom
    this.$rootDom = $tools.checkRootDom(dom, include);

    // this.$rootDom.removeAttribute('id');
  }
  //-----------------------
  static create(dom, args) {
    return new Compile(dom, args);
  }
  //-----------------------
  main() {
    debugger;

    this._checkTemplate();

    this._checkCommandAttr();

    console.log(this.$rootDom.outerHTML);
    // return;

    // 簡化 script 內容
    // 讓 this._proc_1() 加速
    this._script_1();

    // 解析 [%...%]
    let rootDom = this._proc_1();

    // 取回 script 內容
    this._script_2(rootDom);

    debugger;

    let node = this._toCNode(rootDom);

    let fun = this._getRenderFun(node);

    fun = this._wrapRenderFun(fun);

    return fun;
  }
  //-----------------------
  // 處理 template 標籤
  _checkTemplate() {
    // debugger;

    const CommandAttr = $MB.get('CommandAttr');
    const $dom = this.$rootDom;

    while (true) {
      let doms = Array.from($dom.querySelectorAll('template'));
      if (doms.length == 0) {
        break;
      }
      while (doms.length > 0) {
        debugger;
        let dom = doms.shift();

        // 檢查 CommandAttr
        CommandAttr.checkAttrs(dom);

        dom.replaceWith(dom.content);
      } // while
    } // while
  }
  //-----------------------
  // 處理 b-xxx
  _checkCommandAttr() {
    // debugger;

    const $dom = this.$rootDom;
    const CommandAttr = $MB.get('CommandAttr');

    // 取得 b-xxx 列表
    let attrNames = CommandAttr.getAttrNames();

    for (let attrName of attrNames) {
      // debugger;
      let doms = Array.from($dom.querySelectorAll(`[${attrName}]`));
      while (doms.length > 0) {
        // debugger;
        let dom = doms.shift();
        CommandAttr.checkAttrs(dom);
      }
    }
  }
  //-----------------------
  // 簡化 script 內文
  // 加快文本的解析速度
  _script_1() {
    // debugger;

    let doms = this.$rootDom.querySelectorAll('script');
    doms = Array.from(doms);

    doms.forEach((dom) => {
      let id = this.$scriptContent.size;
      id = 'script_' + id;

      let text = dom.textContent;

      this.$scriptContent.set(id, text);

      dom.innerHTML = '';

      if (!dom.hasAttribute('type')) {
        dom.setAttribute('type', 'text/template');
      }
      dom.setAttribute('id', id);
    }); // forEach

    console.log(this.$rootDom.outerHTML);
  }
  //-----------------------
  // 還原 script 內文
  _script_2(rootDom) {
    // debugger;

    for (let [id, text] of this.$scriptContent) {
      debugger;
      let dom = rootDom.querySelector(`#${id}`);
      dom.innerHTML = text;
      dom.removeAttribute('id');
    } // for

    this.$scriptContent.clear();

    console.log(rootDom.outerHTML);
  }
  //-----------------------
  // 取出命令 [%...%]，化爲<script>
  _proc_1() {
    // debugger;
    let content = this.$rootDom.outerHTML;

    let reg_1 = RegExp($reg_1, 'mg');

    // 取出命令 [%...%]，化爲<script>
    content = content.replace(reg_1, (m, g1) => {
      return `<script type="text/template">${g1}</script>`;
    });

    // debugger;
    let dom = document.createElement('div');
    dom.innerHTML = content;
    dom = dom.children[0];

    return dom;
  }
  //-----------------------
  // 將文本形成 cnode 準備 compile 成 vnode
  _toCNode(dom) {
    // debugger;
    const $cnode = $MB.get('cnode');

    let checkList = [];
    let rootNode = $cnode.createNode(dom, null);
    checkList.push(rootNode);
    //--------
    // 將所有 dom 化爲 cnode
    for (let i = 0; checkList[i] != null; i++) {
      let node = checkList[i];

      let list = node.getChilds();
      list.forEach((dom) => {
        // debugger;
        let _node = $cnode.createNode(dom, node);
        checkList.push(_node);
      });
    } // for
    //--------
    return rootNode;
  }
  //-----------------------
  // compile to vnode
  _getRenderFun(node) {
    // debugger;
    let content_1 = node.print();

    let content = 'debugger;\nconst $iter = $scope.getIter();\n';
    content += 'const $data = $scope.getData();\n';
    content += content_1;

    console.log(content);
    //-------------
    let fun = new Function('$scope', content);

    console.log(fun);

    return fun;
  }
  //-----------------------
  // 修飾 renderFuntion
  _wrapRenderFun(_fun) {
    const Scope = $MB.get('CompileScope');

    return function(context, data = {}) {
      // debugger;
      let scope = Scope.create(context, data);
      _fun.call(context, scope);
      let vnode = scope.rootNode;
      return vnode;
    };
  }
  //-----------------------
}

export function handle(mb) {
  $MB = mb;
  return Compile;
};
