let $MB;

const $symbol_1 = Symbol('vnode');

class VNode {
  // 上下文
  $dom;
  $context;
  $parent;
  $childs = [];
  //--------
  $attrs = {};
  $c_attrs = {};
  $p_attrs = {};
  $a_attrs = {};
  $events = {};
  $attr_solutions = {};
  //--------
  $nodeName;
  $tagName;
  $text;
  //--------
  // $targetNode;
  //-----------------------
  constructor(context, p_node, nodeName, tagName) {
    this.$context = context;
    if (p_node != null) {
      this.$parent = p_node;
      p_node.addChild(this);
    }

    this.$nodeName = nodeName;
    if (tagName != null) {
      this.$tagName = tagName;
    }
  }
  //-----------------------
  static create(context, p_node, nodeValue, tagName) {
    return new VNode(context, p_node, nodeValue, tagName);
  }
  //-----------------------
  static getVnode(dom) {
    return (dom[$symbol_1] || null);
  }
  //-----------------------
  get parent() {
    return this.$parent || null;
  }

  get childs() {
    return this.$childs;
  }

  get events() {
    return this.$events;
  }
  //-----------------------
  addChild(node) {
    this.$childs.push(node);
  }

  getDom() {
    return this.$dom;
  }

  getEvents() {
    return this.$events;
  }
  //-----------------------
  // 超重要的地方
  attr(type, ...args) {

    let attrs = {};

    if (args.length == 1) {
      Object.assign(attrs, args[0]);
    } else {
      let [name, value] = args;
      attrs[name] = value;
    }

    for (let name in attrs) {
      let value = attrs[name];

      if (type == null) {
        this.$attrs[name] = value;
      } else {
        switch (type) {
          case 'both':
            this.$c_attrs[name] = value;
            break;
          case 'prop':
            this.$p_attrs[name] = value;
            break;
          case 'attr':
            this.$a_attrs[name] = value;
            break;
        }
      }
    } // while
  }
  //-----------------------
  // 重要的地方
  text(value) {
    this.$text = value;
  }
  //-----------------------
  // 重要地方
  event(name, callback) {
    this.$events[name] = callback;
  }
  //-----------------------
  // 當 dom 要轉移給別的 vnode
  resetDom() {
    if (this.$tagName == null) {
      return;
    }
    // $cAttrs
    for (let key in this.$attr_solutions) {
      let solution = this.$attr_solutions[key];
      solution.remove();
      delete (this.$attr_solutions[key])
    }
    //-------------
    // $attrs
    let attrs = Array.from(this.$dom.attributes);
    while (attrs.length > 0) {
      let { name } = attrs.pop();
      this.$dom.removeAttribute(name);
    }
    //-------------
    // this._destory();
  }
  //-----------------------
  // b-view 讀取
  loadView() {

  }
  //-----------------------
  // 根據 vnode 建立 dom
  // 重點
  // 重點
  // 重點
  // 重點
  buildDom(preNode = null) {
    debugger;

    let dom;
    let pre_events = {};

    if (preNode != null) {

      if (this.$nodeName != preNode.$nodeName) {
        throw new Error('...');
      }
      dom = preNode.getDom();
    } else {
      // 創建 new dom
      dom = this._createDom();

      if (this.parent != null) {
        let rootDom = this.parent.getDom();
        rootDom.appendChild(dom);
      }
    }
    this.$dom = dom;
    dom[$symbol_1] = this;
    //-------------
    if (this.$tagName != null) {

      if (preNode != null) {

        // 還原 dom 預設狀態
        // pre_vnode.resetDom();

        // 之前有綁定過什麼 event
        Object.assign(pre_events, preNode.events);
      }

      // cAttr
      this._buildCAttr(preNode);

      // $attr
      this._buildAttr(preNode);

      // this._buildEvent(pre_events);
    } else {
      dom.nodeValue = this.$text;
    }
    //-------------
  }
  //-----------------------
  // 沒有可匹配的 vnode 可轉移時
  remove() {
    this.$dom.remove();
  }
  //-----------------------
  isSameType(oldNode) {
    // debugger;

    let isSame;

    if (oldNode == null) {
      isSame = false;
    } else {
      isSame = (this.$nodeName == oldNode.$nodeName);
    }
    return isSame;
  }
  //-----------------------
  // 當 build dom 完，不再需要 childs
  clearChilds() {

    while (this.$childs.length > 0) {
      let child = this.$childs.shift();
      child.clearChilds();
    } // while

    this.$childs = undefined;
    delete (this.$childs);
  }
  //-----------------------
  _createDom() {
    // document.createComment
    // document.createElement
    // document.createTextNode
    let dom;
    if (this.$tagName == null) {
      switch (this.$nodeName) {
        case '#text':
          dom = document.createTextNode(this.$text);
          break;
        case '#comment':
          dom = document.createComment(this.$text);
          break;
        default:
          throw new Error(`no support ${this.$nodeName}`);
          break;
      }
    } else {
      dom = document.createElement(this.$tagName);
    }
    return dom;
  }
  //-----------------------
  // 建構 attr
  _buildAttr(preNode) {
    // debugger;

    let dom = this.$dom;

    let pre_attrs = {};

    if (preNode != null) {
      Object.assign(pre_attrs, preNode.$attrs);
    }

    for (let name in this.$attrs) {
      let value = this.$attrs[name];
      if(name in pre_attrs){

        let preValue = pre_attrs[name];

        if(preValue !== value){
          dom.setAttribute(name, value);
        }
        delete(pre_attrs[name]);
      }else{
        dom.setAttribute(name, value);
      }
    } // for
    //-------------
    for (const key in pre_attrs) {
      dom.removeAttribute(key);
    }
  }
  //-----------------------
  // 計算 attr
  // 必須在 _buildAttr() 之前
  _buildCAttr(preNode) {
    debugger;

    let $solutions;
    
    if(preNode == null){
      $solutions = {};
    }else{
      $solutions = Object.assign({}, preNode.$attr_solutions);
    }
    const CpAttrSolution = $MB.get('CpAttrSolution');

    let $checkList = {
      'both': this.$c_attrs,
      'prop': this.$p_attrs,
      'attr': this.$a_attrs,
    };
    //------------------
    for (let type in $checkList) {
      debugger;

      let attrs = $checkList[type];

      for (let name in attrs) {
        debugger;

        let data = attrs[name];
        delete (attrs[name]);

        let attr = null;
        if (name in this.$attrs) {
          attr = this.$attrs[name];

          // attr 交由 compute 解算
          delete (this.$attrs[name]);
        }
        //-------------
        let solution;

        // 取得解算
        if (name in $solutions) {
          solution = $solutions[name];
          delete ($solutions[name]);
        } else {
          solution = CpAttrSolution.get(name, this.$dom);
        }

        // 取得解算
        solution.setProp(type, attr, data);

        this.$attr_solutions[name] = solution;
      }
      //-------------
      // 沒用到的 solution
      for (let key in $solutions) {
        let solution = $solutions[key];
        solution.remove();
        delete (this.$attr_solutions[key]);
      }
    }
  }
  //-----------------------
  _buildEvent(pre_events) {
    debugger;

    const Invoke = $MB.get('Invoke');

    for (let name in this.$events) {
      let callback = this.$events[name];
      let invoke;
      if (name in pre_events) {
        invoke = pre_events[name];
      } else {
        invoke = Invoke.create(this.$dom, name);
      }
      invoke.value = callback;
    }
    //-------------
    for (let name in pre_events) {
      let invoke = pre_events[name];
      invoke.remove();
    }
  }
  //-----------------------
  _destory() {

  }
  //-----------------------
}

export function handle(mb) {
  $MB = mb;
  return VNode;
}
