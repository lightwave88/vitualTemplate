let $MB;
let $singleton;

// 提供計算屬性的解
class CpAttrSolution {
  $solutions = {};
  //-----------------------
  // 單例
  static singleton() {
    if ($singleton == null) {
      $singleton = new CpAttrSolution();
    }
    return $singleton;
  }
  //-----------------------
  constructor() {}
  //-----------------------
  // 設定解決方案
  set(attrName, solution) {
    this.$solutions[attrName] = solution;
  }
  //-----------------------
  // 取得解決方案
  get(attrName, dom) {
    // debugger;

    const $Class = (attrName in this.$solutions) ?
      this.$solutions[attrName] : this.$solutions['#defaut'];

    let solution = new $Class(dom, attrName);
    return solution;
  }
  //-----------------------
  // API
  static set(attrName, solution) {
    let sl = this.singleton();
    sl.set(attrName, solution);
  }

  // API
  static get(attrName, dom) {
    let sl = this.singleton();
    return sl.get(attrName, dom);
  }
  //-----------------------
}
//////////////////////////////
export {
  CpAttrSolution
};

export function handle(mb) {
  $MB = mb;
  return CpAttrSolution;
}
