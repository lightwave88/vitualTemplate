let $MB;

// 取得各種 dom.prop 的初始值
const $prop_defaultValue = {};

const $cpAttrList = {};

// 處理計算屬性
// 原型
class CpAttr {
  $dom;
  $attrName;
  $tagName;
  //-------------
  $attrValue;
  $propData;
  $isProp = false;
  //-----------------------
  constructor(dom, attrName = null) {
    this.$dom = dom;
    this.$tagName = dom.tagName;

    if (attrName != null) {
      this.$attrName = attrName;
    }
  }

  get isProp(){
    return this.$isProp;
  }
  //-----------------------
  // API
  setProp(attrValue, propData) {
    this.$attrValue = attrValue;
    this.$propData = propData;
  }
  //-----------------------
  // API
  remove() {
    const $dom = this.$dom;
    const $attrName = this.$attrName;
    if (this.$isProp) {
      // prop
      let key = this.$tagName + '|' + $attrName;

      if (!(key in $prop_defaultValue)) {
        $prop_defaultValue[$key] = this._getPropDefaultValue(this.$tagName, $attrName);
      }
      $dom[$attrName] = $prop_defaultValue[key];
    } else {
      // attr
      $dom.removeAttribute($attrName);
    }
  }
  //-----------------------
  // tools
  t_setPropByData($attrName, data) {
    debugger;

    const $dom = this.$dom;

    let retry;
    let useAttr = false;

    do {
      debugger;

      retry = false;

      if (!useAttr && ($attrName in $dom)) {
        // setProp

        const type = typeof($dom[$attrName]);
        if (type == 'boolean' && data == '') {
          data = true;
        }
        let preValue = $dom[$attrName];
        if (preValue === data) {
          break;
        }
        $dom[$attrName] = data;

        if ($dom[$attrName] === preValue) {
          // prop 是唯讀。沒設置成功
          retry = true;
          useAttr = true;
        }
      } else {
        // setAttr

        useAttr = true;
        data += '';
        $dom.setAttribute($attrName, data);
      }
    } while (retry);

    this.$isProp = !useAttr;
  }
  //-----------------------
  _getPropDefaultValue(tagName, attrName) {
    let dom = document.createElement(tagName);
    let value = dom[tagName];
    dom = undefined;
    return value;
  }
}
///////////////////////////////////
class Default extends CpAttr {
  setProp(attrValue, propData) {
    debugger;

    // 一般的 attr 只能設置一個數據
    if (attrValue !== undefined) {
      throw new Error('...');
    }
    super.setProp(undefined, propData);

    this.t_setPropByData(this.$attrName, propData);
  }
}

$cpAttrList['#defaut'] = Default;
///////////////////////////////////
class ClassName extends CpAttr {
  $useAttr;
  //-----------------------
  constructor(dom, attrName) {
    super(dom, 'class');
  }
  //-----------------------
  setProp(attrValue, propData) {
    super.setProp(attrValue, propData);
    debugger;
    // 可用的數據類型 (string|[...])
    // 預設分割符號 \s
    let attrs_1 = this.$attrValue.split(/\s{1,}/);

    let attrs_2 = this._checkDataType(propData);

    let attrs = attrs_1.concat(attrs_2);

    attrs = Array.from(new Set(attrs));
    //-------------
    attrs = attrs.join(' ');

    // 化爲 string
    this.t_setPropByData('className', attrs);
  }
  //-----------------------
  _checkDataType(propData) {
    let classList;
    if (typeof(propData) == 'string') {
      classList = [];
      classList.push(propData);
    } else if (Array.isArray(propData)) {
      classList = propData
    } else {
      throw new TypeError('...');
    }
    return classList;
  }
  //-----------------------
  remove() {
    super.remove();
  }
  //-----------------------
}

$cpAttrList['class'] = ClassName;
///////////////////////////////////
class Style extends CpAttr {

  //-----------------------
  constructor(dom, attrName) {
    super(dom, 'style');
  }
  //-----------------------
  setProp() {

  }
  //-----------------------
  remove() {

  }
  //-----------------------
}

$cpAttrList['style'] = Style;
///////////////////////////////////

export {
  CpAttr
};

export function handle(mb) {
  $MB = mb;

  const $CpAttrSolution = $MB.get('CpAttrSolution');

  for (const key in $cpAttrList) {
    $CpAttrSolution.set(key, $cpAttrList[key]);
  }
  return CpAttr;
}
