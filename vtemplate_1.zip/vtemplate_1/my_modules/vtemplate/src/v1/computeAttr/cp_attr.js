let $MB;

// 取得各種 dom.prop 的初始值
const $prop_defaultValue = {};

const $cpAttrList = {};

// 處理計算屬性
// 原型
class CpAttr {
  $dom;
  $attrName;
  $tagName;
  //-------------
  $attrValue;
  $data;
  $isProp;
  // $type;
  // $prevValue = null;
  //-----------------------
  constructor(dom, attrName) {
    this.$dom = dom;
    this.$tagName = dom.tagName;
    this.$attrName = attrName;
  }

  get isProp() {
    return this.$isProp;
  }
  /*
  get isAttr() {
    return !this.$isProp;
  }
  */
  //-----------------------
  // API
  setProp(type, attrValue, data) {
    // 確保有正確的 type
    switch (type) {
      case 'both':
        break;
      case 'attr':
        this.$isProp = false;
        break;
      case 'prop':
        this.$isProp = true;
        break;
      default:
        throw new Error(`no support type(${type})`);
        break;
    }
    this.$attrValue = attrValue;
    this.$data = data;
  }
  //-----------------------
  // API
  remove() {
    const $dom = this.$dom;
    const $attrName = this.$attrName;
    if (this.$isProp) {
      // prop
      let key = this.$tagName + '|' + $attrName;

      if (!(key in $prop_defaultValue)) {
        $prop_defaultValue[key] = this._getPropDefaultValue(this.$tagName, $attrName);
      }
      $dom[$attrName] = $prop_defaultValue[key];
    } else {
      // attr
      $dom.removeAttribute($attrName);
    }
  }
  //-----------------------
  // tools
  t_setAttrByData($attrName, data) {
    const $dom = this.$dom;
    this.$isProp = false;
    data += '';
    $dom.setAttribute($attrName, data);
  }
  //-----------------------
  // tools
  t_setPropByData($attrName, data) {
    debugger;
    const $dom = this.$dom;

    if (!($attrName in $dom)) {
      return false;
    }

    const type = typeof($dom[$attrName]);
    if (type == 'boolean' && data == '') {
      data = true;
    }

    let preValue = $dom[$attrName];
    if (preValue === data) {
      return true;
    }

    $dom[$attrName] = data;
    if ($dom[$attrName] != data) {
      // 唯讀屬性
      return false;
    }
    return true;
  }
  //-----------------------
  // tools
  t_setBothByData($attrName, data) {

    let res = this.t_setPropByData($attrName, data);
    if (res == true) {
      this.$isProp = true;
      return;
    }
    this.$isProp = false;
    this.t_setAttrByData($attrName, data);
  }
  //-----------------------
  _getPropDefaultValue(tagName, attrName) {
    let dom = document.createElement(tagName);
    let value = dom[attrName];
    dom = undefined;
    return value;
  }
}
///////////////////////////////////
class Default extends CpAttr {
  setProp(type, attrValue, data) {
    debugger;

    // 一般的 attr 只能設置一個數據
    if (attrValue != null) {
      throw new Error('...');
    }
    super.setProp(type, attrValue, data);

    const attrName = this.$attrName;
    switch (type) {
      case 'attr':
        this.t_setAttrByData(attrName, data);
        break;
      case 'prop':
        this.t_setPropByData(attrName, data);
        break;
      case 'both':
        this.t_setBothByData(attrName, data);
        break;
    } // switch

    // this.$type = type;
    // this.$prevValue = data;
  }
}

$cpAttrList['#defaut'] = Default;
///////////////////////////////////
class ClassName extends CpAttr {
  $useAttr;
  //-----------------------
  constructor(dom, attrName) {
    super(dom, 'class');
  }
  //-----------------------
  setProp(type, attrValue, data) {
    super.setProp(type, attrValue, data);
    debugger;

    // 預設分割符號 \s
    let attrs_1;

    if (this.$attrValue == null) {
      attrs_1 = [];
    } else {
      attrs_1 = this.$attrValue.split(/\s{1,}/);
    }
    //-------------
    // 可用的數據類型 (string|[...])
    let attrs_2 = this._checkDataType(data);

    while (attrs_2.length > 0) {
      let name = attrs_2.shift();
      if (attrs_1.includes(name)) {
        continue;
      }
      attrs_1.push(name);
    }
    //-------------
    attrs_1 = attrs_1.join(' ');

    switch (type) {
      case 'attr':
        this.t_setAttrByData('class', attrs_1);
        break;
      case 'prop':
      case 'both':
        this.t_setPropByData('className', attrs_1);
        break;
    }
    //-------------
    // this.$type = type;
    // this.$prevValue = attrs_1;
  }
  //-----------------------
  _checkDataType(propData) {
    let classList;
    if (typeof(propData) == 'string') {
      classList = [];
      classList.push(propData);
    } else if (Array.isArray(propData)) {
      classList = propData
    } else {
      throw new TypeError('...');
    }
    return classList;
  }
  //-----------------------
  remove() {
    super.remove();
  }
  //-----------------------
}

$cpAttrList['class'] = ClassName;
///////////////////////////////////
class Style extends CpAttr {

  //-----------------------
  constructor(dom, attrName) {
    super(dom, 'style');
  }
  //-----------------------
  setProp() {

  }
  //-----------------------
  remove() {

  }
  //-----------------------
}

$cpAttrList['style'] = Style;
///////////////////////////////////

export {
  CpAttr
};

export function handle(mb) {
  $MB = mb;

  const $CpAttrSolution = $MB.get('CpAttrSolution');

  for (const key in $cpAttrList) {
    $CpAttrSolution.set(key, $cpAttrList[key]);
  }
  return CpAttr;
}
