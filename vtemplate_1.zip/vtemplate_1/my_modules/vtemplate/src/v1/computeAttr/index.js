// debugger;

import $MB from '../mb.js';
const $mb = new $MB();

//------------------
// debugger;
import {
  handle as h_cpAttrSl
} from './cp_attr_Solution.js';

$mb.importHandle('CpAttrSolution', h_cpAttrSl);
//------------------
// debugger;
import {
  handle as h_cpAttr
} from './cp_attr.js';

$mb.importHandle(h_cpAttr);
//------------------
$mb.export(function() {
  // debugger;
  const CpAttrSolution = this.get('CpAttrSolution');
  return CpAttrSolution;
});

export default $mb;
