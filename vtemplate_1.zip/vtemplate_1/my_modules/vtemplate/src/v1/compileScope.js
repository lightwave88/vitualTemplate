let $MB;

class CompileScope {
  $$rootNdoe;
  $$context;
  $$data;
  //------------------
  constructor(context, data) {
    this.$$context = context || null;
    this.$$data = data;
  }

  static create(context, data) {
    let scope = new CompileScope(context, data);
    return scope;
  }
  //------------------
  get rootNode() {
    return this.$$rootNdoe || null;
  }
  //------------------
  createNode(p_node, nodeValue, tagName = null) {
    const VNode = $MB.get('VNode');
    let vnode = VNode.create(this.$$context, p_node, nodeValue, tagName);

    if (this.$$rootNdoe == null) {
      this.$$rootNdoe = vnode;
    }
    return vnode;
  }
  //------------------
  getData() {
    return this.$$data;
  }
  //------------------
  // 返回一個可以製造 iterator 的 fun
  getIter() {
    const $tools = $MB.get('tools');
    return function(data) {
      let it = $tools.makeIterator(data)
      return it;
    }
  }
  //------------------
  getFilter() {

  }
  //------------------
  stringify(value, ...filters) {
    const $tools = $MB.get('tools');
    return $tools.stringify(value, filters);
  }
}


export function handle(mb) {
  $MB = mb;
  return CompileScope;
}
