debugger;
const $iter = $scope.getIter();
const $data = $scope.getData();

let $$_pNode;
let $$_node;
$$_node = $scope.createNode($$_pNode, "div", "div");
{
	const $$_pNode = $$_node;

	$$_node = $scope.createNode($$_pNode, "#text", null);
	$$_node.text("\n    ");
	$$_node = $scope.createNode($$_pNode, "div", "div");
	$$_node.attr("class", "a");
	{
		const $$_pNode = $$_node;

		$$_node = $scope.createNode($$_pNode, "#text", null);
		$$_node.text("\n      name = " + $scope.stringify($data.age) + "\n    ");
		$$_node = $$_pNode;
	}
	$$_node = $scope.createNode($$_pNode, "#text", null);
	$$_node.text("\n  ");
	$$_node = $$_pNode;
}