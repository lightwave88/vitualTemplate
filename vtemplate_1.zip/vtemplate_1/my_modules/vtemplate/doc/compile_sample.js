let $$_pNode;
let $$_node;
$$_node = $scope.creatNode($$_pNode, "div", "DIV");
{
  const $$_pNode = $$_node;

  $$_node = $scope.creatNode($$_pNode, "#text", null);
  $$_node.text("\n      ");

  for (let i = 0; i < 2; i++) {


    $$_node = $scope.creatNode($$_pNode, "#text", null);
    $$_node.text("\n      ");
    $$_node = $scope.creatNode($$_pNode, "div", "DIV");
    {
      const $$_pNode = $$_node;

      $$_node = $scope.creatNode($$_pNode, "#text", null);
      $$_node.text("\n        index = " + $scope.toString(i) + "\n      ");
      $$_node = $$_pNode;
    }
    $$_node = $scope.creatNode($$_pNode, "#text", null);
    $$_node.text("\n      ");

  }

  $$_node = $scope.creatNode($$_pNode, "#text", null);
  $$_node.text("\n    ");
  $$_node = $$_pNode;
}
