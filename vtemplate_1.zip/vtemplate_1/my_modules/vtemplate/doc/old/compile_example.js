function compile() {
	let parent;
	let node;
	node = creatNode(parent, 'div', 'div');
	{
		let parent = node;
		node = creatNode(parent, '#text', null);
		node.setText("\n      hi\n      ");
		node = creatNode(parent, 'p', 'p');
		{
			let parent = node;
			node = creatNode(parent, '#text', null);
			node.setText("\n        a\n      ");
			node = parent;
		}
		node = creatNode(parent, '#text', null);
		node.setText("\n    ");
		node = parent;
	}
	return node;
}
//----------------------------
function createNode() {
	let node;

	return node;
}
