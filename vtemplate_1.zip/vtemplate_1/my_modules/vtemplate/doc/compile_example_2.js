debugger;
const $iter = $scope.getIter();
const $data = $scope.getData();

let $$_pNode;
let $$_node;
$$_node = $scope.createNode($$_pNode, "div", "div");
{
  const $$_pNode = $$_node;

  $$_node = $scope.createNode($$_pNode, "#text", null);
  $$_node.text("\n    ");
  for (let [item] of $data.list) {

    $$_node = $scope.createNode($$_pNode, "div", "div");
    {
      const $$_pNode = $$_node;

      $$_node = $scope.createNode($$_pNode, "#text", null);
      $$_node.text("\n      ");
      $$_node = $scope.createNode($$_pNode, "p", "p");
      {
        const $$_pNode = $$_node;

        $$_node = $scope.createNode($$_pNode, "#text", null);
        $$_node.text("\n        data = " + $scope.stringify(item) + "\n      ");
        $$_node = $$_pNode;
      }
      $$_node = $scope.createNode($$_pNode, "#text", null);
      $$_node.text("\n    ");
      $$_node = $$_pNode;
    }
  }

  $$_node = $scope.createNode($$_pNode, "#text", null);
  $$_node.text("\n  ");
  $$_node = $$_pNode;
}