const $iter = $scope.getIter();

let $$_pNode;
let $$_node;
$$_node = $scope.creatNode($$_pNode, "div", "DIV");
{
  const $$_pNode = $$_node;

  $$_node = $scope.creatNode($$_pNode, "#text", null);
  $$_node.text("\n    ");
  for (let [item, k,] of $data.list) {

    $$_node = $scope.creatNode($$_pNode, "div", "DIV");
    {
      const $$_pNode = $$_node;

      $$_node = $scope.creatNode($$_pNode, "#text", null);
      $$_node.text("\n      ");
      $$_node = $scope.creatNode($$_pNode, "p", "P");
      {
        const $$_pNode = $$_node;

        $$_node = $scope.creatNode($$_pNode, "#text", null);
        $$_node.text("\n        data = " + $scope.toString(item) + "\n      ");
        $$_node = $$_pNode;
      }
      $$_node = $scope.creatNode($$_pNode, "#text", null);
      $$_node.text("\n    ");
      $$_node = $$_pNode;
    }
  }

  $$_node = $scope.creatNode($$_pNode, "#text", null);
  $$_node.text("\n  ");
  $$_node = $$_pNode;
}