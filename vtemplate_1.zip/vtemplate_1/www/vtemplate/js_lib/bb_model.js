import * from 'http://localhost:8082/output/model.js';
