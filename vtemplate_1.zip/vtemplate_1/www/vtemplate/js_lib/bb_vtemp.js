// debugger;
//------------------
import { $bb as bb } from '/my_modules/bb_core/index.js';
if (window['$bb'] == null) {
  window['$bb'] = bb;
}
//------------------
import {
  handle as h_vtemplate
} from '/my_modules/vtemplate/index.js';
h_vtemplate(window['$bb']);
//------------------
